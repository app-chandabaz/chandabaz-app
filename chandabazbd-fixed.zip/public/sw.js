/* চাঁন্দাবাজ বিডি — সার্ভিস ওয়ার্কার (অফলাইন ক্যাশ) */
const V = "v2";
const SHELL = `shell-${V}`;
const RUNTIME = `runtime-${V}`;
const IMAGES = `images-${V}`; // ছবি ও YouTube থাম্বনেইল (ফোনের মেমরি ক্যাশ)
const SHELL_FILES = ["./", "./index.html", "./manifest.webmanifest", "./icon-192.png", "./icon-512.png"];
const MAX_RUNTIME = 120;
const MAX_IMAGES = 300;

self.addEventListener("install", (e) => {
  e.waitUntil(
    caches
      .open(SHELL)
      .then((c) => Promise.allSettled(SHELL_FILES.map((f) => c.add(f))))
      .then(() => self.skipWaiting())
  );
});

self.addEventListener("activate", (e) => {
  e.waitUntil(
    caches
      .keys()
      .then((keys) => Promise.all(keys.filter((k) => ![SHELL, RUNTIME, IMAGES].includes(k)).map((k) => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

async function trim(cache, max = MAX_RUNTIME) {
  const keys = await cache.keys();
  if (keys.length > max) await Promise.all(keys.slice(0, keys.length - max).map((k) => cache.delete(k)));
}

async function networkFirst(req, cacheName, fallbackKey) {
  const cache = await caches.open(cacheName);
  try {
    const res = await fetch(req);
    if (res && res.ok) {
      cache.put(fallbackKey || req, res.clone());
      if (cacheName === RUNTIME) trim(cache);
    }
    return res;
  } catch (err) {
    const hit = await cache.match(fallbackKey || req);
    if (hit) return hit;
    throw err;
  }
}

async function staleWhileRevalidate(req, cacheName = RUNTIME, max = MAX_RUNTIME) {
  const cache = await caches.open(cacheName);
  const hit = await cache.match(req);
  const net = fetch(req)
    .then((res) => {
      if (res && (res.ok || res.type === "opaque")) {
        cache.put(req, res.clone());
        trim(cache, max);
      }
      return res;
    })
    .catch(() => hit);
  return hit || net;
}

self.addEventListener("fetch", (e) => {
  const req = e.request;
  if (req.method !== "GET") return;
  const url = new URL(req.url);

  // পেজ নেভিগেশন: নেটওয়ার্ক আগে, না থাকলে ক্যাশ করা অ্যাপ শেল
  if (req.mode === "navigate") {
    e.respondWith(networkFirst(req, SHELL, "./index.html"));
    return;
  }
  // ছবি (খবরের ছবি + i.ytimg.com থাম্বনেইল): আলাদা বড় ক্যাশে
  if (req.destination === "image" || url.hostname === "i.ytimg.com") {
    e.respondWith(staleWhileRevalidate(req, IMAGES, MAX_IMAGES));
    return;
  }
  // নিজের ফাইল ও ফন্ট
  if (
    url.origin === self.location.origin ||
    url.hostname === "fonts.googleapis.com" ||
    url.hostname === "fonts.gstatic.com"
  ) {
    e.respondWith(staleWhileRevalidate(req));
    return;
  }
  // সাইটের পাবলিক পোস্ট API: নেটওয়ার্ক আগে, অফলাইনে সর্বশেষ ক্যাশ
  if (url.hostname === "chandabazbd.com" && url.pathname.startsWith("/wp-json/")) {
    e.respondWith(networkFirst(req, RUNTIME));
  }
});
