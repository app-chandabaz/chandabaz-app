/* চাঁন্দাবাজ বিডি — সার্ভিস ওয়ার্কার (অফলাইন ক্যাশ) */
const V = "v1";
const SHELL = `shell-${V}`;
const RUNTIME = `runtime-${V}`;
const SHELL_FILES = ["./", "./index.html", "./manifest.webmanifest", "./icon-192.png", "./icon-512.png"];
const MAX_RUNTIME = 120;

self.addEventListener("install", (e) => {
  e.waitUntil(
    caches
      .open(SHELL)
      .then((c) => Promise.allSettled(SHELL_FILES.map((f) => c.add(f))))
      .then(() => self.skipWaiting())
  );
});

self.addEventListener("activate", (e) => {
  e.waitUntil(
    caches
      .keys()
      .then((keys) => Promise.all(keys.filter((k) => ![SHELL, RUNTIME].includes(k)).map((k) => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

async function trim(cache) {
  const keys = await cache.keys();
  if (keys.length > MAX_RUNTIME) await Promise.all(keys.slice(0, keys.length - MAX_RUNTIME).map((k) => cache.delete(k)));
}

async function networkFirst(req, cacheName, fallbackKey) {
  const cache = await caches.open(cacheName);
  try {
    const res = await fetch(req);
    if (res && res.ok) {
      cache.put(fallbackKey || req, res.clone());
      if (cacheName === RUNTIME) trim(cache);
    }
    return res;
  } catch (err) {
    const hit = await cache.match(fallbackKey || req);
    if (hit) return hit;
    throw err;
  }
}

async function staleWhileRevalidate(req) {
  const cache = await caches.open(RUNTIME);
  const hit = await cache.match(req);
  const net = fetch(req)
    .then((res) => {
      if (res && (res.ok || res.type === "opaque")) {
        cache.put(req, res.clone());
        trim(cache);
      }
      return res;
    })
    .catch(() => hit);
  return hit || net;
}

self.addEventListener("fetch", (e) => {
  const req = e.request;
  if (req.method !== "GET") return;
  const url = new URL(req.url);

  // পেজ নেভিগেশন: নেটওয়ার্ক আগে, না থাকলে ক্যাশ করা অ্যাপ শেল
  if (req.mode === "navigate") {
    e.respondWith(networkFirst(req, SHELL, "./index.html"));
    return;
  }
  // নিজের ফাইল, ফন্ট ও ছবি
  if (
    url.origin === self.location.origin ||
    url.hostname === "fonts.googleapis.com" ||
    url.hostname === "fonts.gstatic.com" ||
    req.destination === "image"
  ) {
    e.respondWith(staleWhileRevalidate(req));
    return;
  }
  // সাইটের পাবলিক পোস্ট API: নেটওয়ার্ক আগে, অফলাইনে সর্বশেষ ক্যাশ
  if (url.hostname === "chandabazbd.com" && url.pathname.startsWith("/wp-json/")) {
    e.respondWith(networkFirst(req, RUNTIME));
  }
});
