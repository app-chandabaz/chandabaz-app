import { useCallback, useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import { AppProvider, useApp } from "@/lib/store";
import { SITE, type Post, type WpCategory } from "@/lib/api";
import { useCategories } from "@/lib/useNews";
import { BottomNav, BreakingTicker, StatusBar, TopBar, type TabId } from "@/components/Chrome";
import { Icon, Logo } from "@/components/Icons";
import { Toasts } from "@/components/ui";
import Splash from "@/components/Splash";
import NotificationsSheet, { type Notif } from "@/components/NotificationsSheet";
import HomeScreen from "@/screens/HomeScreen";
import { CategoriesScreen, CategoryDetailScreen } from "@/screens/CategoriesScreen";
import WorldScreen from "@/screens/WorldScreen";
import SavedScreen from "@/screens/SavedScreen";
import MoreScreen from "@/screens/MoreScreen";
import ArticleScreen from "@/screens/ArticleScreen";
import VideoScreen from "@/screens/VideoScreen";
import VideoPlayer from "@/components/VideoPlayer";
import type { Video } from "@/lib/youtube";
import SearchScreen from "@/screens/SearchScreen";
import { haptic, timeAgo } from "@/lib/utils";

type Route =
  | { t: "article"; post: Post }
  | { t: "search" }
  | { t: "video"; video: Video }
  | { t: "category"; cat: WpCategory };

interface BIPEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: string }>;
}

function PushPopup({
  post,
  onOpen,
  onClose,
}: {
  post: Post;
  onOpen: () => void;
  onClose: () => void;
}) {
  return (
    <div className="animate-slide-up absolute inset-x-3 top-3 z-[80]">
      <div className="flex items-start gap-2.5 rounded-2xl bg-white/95 p-3 shadow-2xl ring-1 ring-black/5 backdrop-blur dark:bg-ink-700/95 dark:ring-white/10">
        <Logo size={34} />
        <button onClick={onOpen} className="min-w-0 flex-1 text-left">
          <div className="flex items-center gap-1.5">
            <span className="text-[11px] font-bold text-brand-600">চাঁন্দাবাজ বিডি</span>
            <span className="text-[10px] text-zinc-400">· এইমাত্র</span>
          </div>
          <p className="line-clamp-2 text-[12.5px] font-semibold leading-snug text-zinc-800 dark:text-zinc-100">
            ⚡ {post.title}
          </p>
        </button>
        <button onClick={onClose} className="shrink-0 text-zinc-400">
          <Icon name="close" size={16} />
        </button>
      </div>
    </div>
  );
}

function OfflineBar() {
  return (
    <div className="flex items-center justify-center gap-2 bg-zinc-800 py-1.5 text-[11.5px] font-medium text-amber-300">
      <Icon name="wifiOff" size={13} /> ইন্টারনেট সংযোগ নেই — সংরক্ষিত সংবাদ পড়তে পারবেন
    </div>
  );
}

function SwipeBack({ onBack, children }: { onBack: () => void; children: ReactNode }) {
  const [dx, setDx] = useState(0);
  const start = useRef<number | null>(null);
  return (
    <div
      className="absolute inset-0 z-40"
      style={{ transform: `translateX(${dx}px)`, transition: dx ? "none" : "transform .25s" }}
      onTouchStart={(e) => {
        if (e.touches[0].clientX < 34) start.current = e.touches[0].clientX;
      }}
      onTouchMove={(e) => {
        if (start.current === null) return;
        setDx(Math.max(0, e.touches[0].clientX - start.current));
      }}
      onTouchEnd={() => {
        if (dx > 90) onBack();
        setDx(0);
        start.current = null;
      }}
    >
      {children}
    </div>
  );
}

function Shell() {
  const { dark, saved, pushHistory, pushBreaking } = useApp();
  const { cats, catMap } = useCategories();

  const [booting, setBooting] = useState(true);
  const [splashGone, setSplashGone] = useState(false);
  const [tab, setTab] = useState<TabId>("home");
  const [stack, setStack] = useState<Route[]>([]);
  const [notifOpen, setNotifOpen] = useState(false);
  const [notifs, setNotifs] = useState<Notif[]>([]);
  const [push, setPush] = useState<Post | null>(null);
  const [online, setOnline] = useState(true);
  const [deferred, setDeferred] = useState<BIPEvent | null>(null);
  const seeded = useRef(false);

  const top = stack[stack.length - 1];
  const unread = notifs.filter((n) => !n.read).length;

  /* টিকার + নোটিফিকেশন + সম্পর্কিত সংবাদের জন্য হোম ফিড থেকে পাওয়া সর্বশেষ পোস্ট */
  const [latest, setLatest] = useState<Post[]>([]);

  /* splash */
  useEffect(() => {
    const a = setTimeout(() => setBooting(false), 1600);
    const b = setTimeout(() => setSplashGone(true), 2150);
    return () => {
      clearTimeout(a);
      clearTimeout(b);
    };
  }, []);

  /* নোটিফিকেশন তালিকা তৈরি */
  useEffect(() => {
    if (!latest.length || seeded.current) return;
    seeded.current = true;
    setNotifs(
      latest.slice(0, 6).map((p, i) => ({
        id: `n-${p.id}`,
        post: p,
        type: i === 0 ? "breaking" : i < 3 ? "update" : "world",
        read: i > 2,
      }))
    );
  }, [latest]);

  /* ইনস্টল প্রম্পট (manifest ও আইকন এখন public/ ফোল্ডারে স্থির ফাইল) */
  useEffect(() => {
    const onBip = (e: Event) => {
      e.preventDefault();
      setDeferred(e as BIPEvent);
    };
    const onInstalled = () => setDeferred(null);
    window.addEventListener("beforeinstallprompt", onBip);
    window.addEventListener("appinstalled", onInstalled);
    return () => {
      window.removeEventListener("beforeinstallprompt", onBip);
      window.removeEventListener("appinstalled", onInstalled);
    };
  }, []);

  /* connectivity */
  useEffect(() => {
    const sync = () => setOnline(navigator.onLine);
    sync();
    window.addEventListener("online", sync);
    window.addEventListener("offline", sync);
    return () => {
      window.removeEventListener("online", sync);
      window.removeEventListener("offline", sync);
    };
  }, []);

  const openPost = useCallback(
    (p: Post) => {
      haptic();
      pushHistory(p);
      setStack((s) => [...s, { t: "article", post: p }]);
    },
    [pushHistory]
  );

  /* সর্বশেষ সংবাদের পুশ অ্যালার্ট */
  useEffect(() => {
    if (booting || !pushBreaking || !latest.length) return;
    const t = setTimeout(() => {
      setPush(latest[0]);
      haptic(25);
      setTimeout(() => setPush(null), 7000);
    }, 8000);
    return () => clearTimeout(t);
  }, [booting, pushBreaking, latest]);

  /* keyboard back */
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape" && stack.length) setStack((s) => s.slice(0, -1));
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [stack.length]);

  const install = async () => {
    if (!deferred) return;
    await deferred.prompt();
    await deferred.userChoice;
    setDeferred(null);
  };

  const pop = () => setStack((s) => s.slice(0, -1));
  const openCategory = (c: WpCategory) => setStack((s) => [...s, { t: "category", cat: c }]);

  const related = useMemo(() => {
    if (top?.t !== "article") return [];
    return latest.filter((p) => p.id !== top.post.id).slice(0, 5);
  }, [top, latest]);

  const tabScreen = () => {
    switch (tab) {
      case "home":
        return (
          <HomeScreen
            cats={cats}
            catMap={catMap}
            onOpen={openPost}
            onOpenCategory={openCategory}
            onGoWorld={() => setTab("world")}
            onLatest={setLatest}
          />
        );
      case "categories":
        return <CategoriesScreen cats={cats} onOpenCategory={openCategory} />;
      case "world":
        return <WorldScreen onOpen={openPost} />;
      case "videos":
        return <VideoScreen onPlay={(v) => setStack((s) => [...s, { t: "video", video: v }])} />;
      case "saved":
        return <SavedScreen onOpen={openPost} onGoHome={() => setTab("home")} />;
      case "more":
        return (
          <MoreScreen
            canInstall={!!deferred}
            onInstall={install}
            onGoWorld={() => setTab("world")}
          />
        );
    }
  };

  return (
    <div className={dark ? "dark" : ""}>
      <div className="flex min-h-[100dvh] w-full items-center justify-center bg-zinc-100 dark:bg-[#07090c] lg:gap-12 lg:p-10">
        {/* desktop panel */}
        <aside className="hidden max-w-sm shrink-0 lg:block">
          <div className="flex items-center gap-3">
            <Logo size={52} />
            <div>
              <h1 className="font-serif-bn text-[25px] font-bold leading-tight text-zinc-900 dark:text-white">
                চাঁন্দাবাজ বিডি
              </h1>
              <p className="text-[13px] text-zinc-500 dark:text-zinc-400">
                অফিশিয়াল মোবাইল নিউজ অ্যাপ
              </p>
            </div>
          </div>
          <p className="mt-5 text-[14.5px] leading-relaxed text-zinc-600 dark:text-zinc-400">
            সত্য ও বস্তুনিষ্ঠ সংবাদ পরিবেশনে প্রতিশ্রুতিবদ্ধ। অ্যাপটি{" "}
            <strong className="text-zinc-800 dark:text-zinc-200">chandabazbd.com</strong>-এর লাইভ
            API থেকে সরাসরি খবর আনে, সঙ্গে আন্তর্জাতিক সংবাদ সংস্থার ফিড।
          </p>
          <ul className="mt-5 space-y-2.5">
            {[
              ["🔗", "WordPress + AppNatively API সংযুক্ত"],
              ["🌍", "BBC, প্রথম আলো, Al Jazeera, UN News"],
              ["🔖", "অফলাইনে পড়ার জন্য সংরক্ষণ"],
              ["🔍", "সরাসরি সার্ভার সার্চ ও বিভাগ ব্রাউজিং"],
              ["🌙", "ডার্ক মোড ও লেখার আকার নিয়ন্ত্রণ"],
            ].map(([i, t]) => (
              <li
                key={t}
                className="flex items-center gap-3 text-[13.5px] text-zinc-700 dark:text-zinc-300"
              >
                <span className="grid h-8 w-8 place-items-center rounded-xl bg-white shadow-sm dark:bg-ink-800">
                  {i}
                </span>
                {t}
              </li>
            ))}
          </ul>
          <div className="mt-6 flex flex-wrap gap-3">
            <button
              onClick={install}
              className="flex items-center gap-2 rounded-xl bg-brand-600 px-5 py-3 text-[14px] font-bold text-white shadow-lg shadow-brand-600/25 transition hover:bg-brand-700"
            >
              <Icon name="download" size={17} /> অ্যাপ ইনস্টল করুন
            </button>
            <a
              href={SITE}
              target="_blank"
              rel="noreferrer"
              className="flex items-center gap-2 rounded-xl bg-white px-5 py-3 text-[14px] font-bold text-zinc-700 shadow-sm ring-1 ring-zinc-200 transition hover:bg-zinc-50 dark:bg-ink-800 dark:text-zinc-200 dark:ring-ink-700"
            >
              <Icon name="globe" size={17} /> ওয়েবসাইট
            </a>
          </div>
          {latest[0] && (
            <p className="mt-5 text-[12px] text-zinc-400">
              সর্বশেষ প্রকাশ: {timeAgo(latest[0].minutesAgo)} · সংস্করণ ২.০.০
            </p>
          )}
        </aside>

        {/* phone */}
        <div className="relative mx-auto h-[100dvh] w-full overflow-hidden bg-white shadow-2xl dark:bg-ink-900 lg:h-[824px] lg:w-[392px] lg:rounded-[40px] lg:ring-[11px] lg:ring-zinc-900 dark:lg:ring-black">
          <div className="absolute left-1/2 top-0 z-[75] hidden h-6 w-32 -translate-x-1/2 rounded-b-2xl bg-zinc-900 lg:block dark:bg-black" />

          <div className="flex h-full flex-col">
            <div className="hidden lg:block">
              <StatusBar />
            </div>
            {!top && (
              <>
                <TopBar
                  onSearch={() => setStack((s) => [...s, { t: "search" }])}
                  onBell={() => setNotifOpen(true)}
                  unread={unread}
                />
                {tab === "home" && <BreakingTicker posts={latest} onOpen={openPost} />}
              </>
            )}
            {!online && <OfflineBar />}

            <main className="relative flex-1 overflow-hidden">
              {tabScreen()}

              {top?.t === "article" && (
                <SwipeBack onBack={pop}>
                  <ArticleScreen
                    post={top.post}
                    related={related}
                    onBack={pop}
                    onOpen={openPost}
                  />
                </SwipeBack>
              )}
              {top?.t === "video" && (
                <SwipeBack onBack={pop}>
                  <VideoPlayer video={top.video} onBack={pop} />
                </SwipeBack>
              )}
              {top?.t === "search" && (
                <SwipeBack onBack={pop}>
                  <SearchScreen catMap={catMap} onBack={pop} onOpen={openPost} />
                </SwipeBack>
              )}
              {top?.t === "category" && (
                <SwipeBack onBack={pop}>
                  <CategoryDetailScreen
                    cat={top.cat}
                    catMap={catMap}
                    onBack={pop}
                    onOpen={openPost}
                  />
                </SwipeBack>
              )}
            </main>

            {!top && (
              <BottomNav
                active={tab}
                savedCount={saved.length}
                onChange={(t) => {
                  setStack([]);
                  setTab(t);
                }}
              />
            )}
          </div>

          <NotificationsSheet
            open={notifOpen}
            onClose={() => setNotifOpen(false)}
            notifs={notifs}
            onReadAll={() => setNotifs((n) => n.map((x) => ({ ...x, read: true })))}
            onOpen={openPost}
          />

          {push && (
            <PushPopup
              post={push}
              onOpen={() => {
                setPush(null);
                openPost(push);
              }}
              onClose={() => setPush(null)}
            />
          )}

          <Toasts />
          {!splashGone && <Splash hiding={!booting} />}
        </div>
      </div>
    </div>
  );
}

export default function App() {
  return (
    <AppProvider>
      <Shell />
    </AppProvider>
  );
}
