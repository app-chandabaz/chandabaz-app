import { useEffect, useRef, useState } from "react";
import type { Post, WpCategory } from "@/lib/api";
import { banglaDate, clockHHMM, haptic } from "@/lib/utils";
import { useApp } from "@/lib/store";
import { Icon, Logo } from "./Icons";
import { cn } from "@/utils/cn";

export type TabId = "home" | "categories" | "world" | "videos" | "saved" | "more";

export function TopBar({
  onSearch,
  onBell,
  unread,
}: {
  onSearch: () => void;
  onBell: () => void;
  unread: number;
}) {
  const { dark, set } = useApp();
  return (
    <div className="bg-gradient-to-r from-brand-800 via-brand-700 to-brand-600 px-4 pb-2.5 pt-3 text-white shadow-md">
      <div className="flex items-center gap-2.5">
        <Logo size={38} />
        <div className="min-w-0 flex-1 leading-tight">
          <h1 className="font-serif-bn text-[18px] font-bold tracking-tight">চাঁন্দাবাজ বিডি</h1>
          <p className="truncate text-[10px] text-white/75">{banglaDate()}</p>
        </div>
        <button
          onClick={() => {
            haptic();
            set("dark", !dark);
          }}
          className="grid h-9 w-9 place-items-center rounded-full bg-white/15 active:scale-90"
          aria-label="থিম"
        >
          <Icon name={dark ? "sun" : "moon"} size={18} />
        </button>
        <button
          onClick={onBell}
          className="relative grid h-9 w-9 place-items-center rounded-full bg-white/15 active:scale-90"
          aria-label="নোটিফিকেশন"
        >
          <Icon name="bell" size={18} />
          {unread > 0 && (
            <span className="absolute right-1 top-1 h-2 w-2 rounded-full bg-amber-300 ring-2 ring-brand-700" />
          )}
        </button>
        <button
          onClick={onSearch}
          className="grid h-9 w-9 place-items-center rounded-full bg-white/15 active:scale-90"
          aria-label="খুঁজুন"
        >
          <Icon name="search" size={18} />
        </button>
      </div>
    </div>
  );
}

export function BreakingTicker({
  posts,
  onOpen,
}: {
  posts: Post[];
  onOpen: (p: Post) => void;
}) {
  if (!posts.length) return null;
  const items = [...posts, ...posts];
  return (
    <div className="flex items-stretch overflow-hidden border-b border-zinc-200 bg-white dark:border-ink-700 dark:bg-ink-800">
      <div className="flex shrink-0 items-center gap-1 bg-brand-600 px-2.5 text-[11px] font-bold text-white">
        <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-white" />
        সর্বশেষ
      </div>
      <div className="relative flex-1 overflow-hidden py-1.5">
        <div className="animate-marquee flex w-max gap-8 whitespace-nowrap pl-3">
          {items.map((p, i) => (
            <button
              key={`${p.id}-${i}`}
              onClick={() => onOpen(p)}
              className="text-[12.5px] font-medium text-zinc-700 dark:text-zinc-300"
            >
              • {p.title}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}

export function CategoryStrip({
  cats,
  active,
  onSelect,
}: {
  cats: WpCategory[];
  active: number | null;
  onSelect: (id: number | null) => void;
}) {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const el = ref.current?.querySelector<HTMLElement>(`[data-cat="${active ?? "all"}"]`);
    el?.scrollIntoView({ behavior: "smooth", inline: "center", block: "nearest" });
  }, [active]);

  const items = [{ id: null as number | null, name: "⚡ সর্বশেষ" }, ...cats.map((c) => ({ id: c.id as number | null, name: c.name }))];

  return (
    <div
      ref={ref}
      className="no-scrollbar flex gap-2 overflow-x-auto border-b border-zinc-200 bg-white px-3 py-2.5 dark:border-ink-700 dark:bg-ink-900"
    >
      {items.map((c) => (
        <button
          key={String(c.id)}
          data-cat={c.id ?? "all"}
          onClick={() => {
            haptic(8);
            onSelect(c.id);
          }}
          className={cn(
            "shrink-0 rounded-full px-3.5 py-1.5 text-[13px] font-semibold transition",
            active === c.id
              ? "bg-brand-600 text-white shadow-md shadow-brand-600/25"
              : "bg-zinc-100 text-zinc-600 dark:bg-ink-700 dark:text-zinc-300"
          )}
        >
          {c.name}
        </button>
      ))}
      {!cats.length && (
        <>
          {[0, 1, 2, 3].map((i) => (
            <span
              key={i}
              className="h-7 w-20 shrink-0 animate-pulse rounded-full bg-zinc-100 dark:bg-ink-700"
            />
          ))}
        </>
      )}
    </div>
  );
}

const tabs: { id: TabId; label: string; icon: string }[] = [
  { id: "home", label: "হোম", icon: "home" },
  { id: "categories", label: "বিভাগ", icon: "grid" },
  { id: "world", label: "বিশ্ব", icon: "globe" },
  { id: "videos", label: "ভিডিও", icon: "play" },
  { id: "saved", label: "সেভড", icon: "bookmark" },
  { id: "more", label: "আরও", icon: "menu" },
];

const bnNum = ["০", "১", "২", "৩", "৪", "৫", "৬", "৭", "৮", "৯"];

export function BottomNav({
  active,
  onChange,
  savedCount,
}: {
  active: TabId;
  onChange: (t: TabId) => void;
  savedCount: number;
}) {
  return (
    <nav className="relative z-30 flex border-t border-zinc-200 bg-white/95 pb-[env(safe-area-inset-bottom)] backdrop-blur dark:border-ink-700 dark:bg-ink-800/95">
      {tabs.map((t) => {
        const on = active === t.id;
        return (
          <button
            key={t.id}
            onClick={() => {
              haptic(8);
              onChange(t.id);
            }}
            className="relative flex flex-1 flex-col items-center gap-0.5 py-2"
          >
            <span
              className={cn(
                "absolute top-0 h-[3px] w-8 rounded-b-full bg-brand-600 transition-all duration-300",
                on ? "opacity-100" : "scale-x-0 opacity-0"
              )}
            />
            <span className="relative">
              <Icon
                name={t.icon}
                size={21}
                filled={on && t.id === "saved"}
                className={cn(
                  "transition-colors",
                  on ? "text-brand-600 dark:text-brand-400" : "text-zinc-400 dark:text-zinc-500"
                )}
              />
              {t.id === "saved" && savedCount > 0 && (
                <span className="absolute -right-2 -top-1.5 grid h-4 min-w-4 place-items-center rounded-full bg-brand-600 px-1 text-[9px] font-bold text-white">
                  {savedCount > 9 ? "৯+" : bnNum[savedCount]}
                </span>
              )}
            </span>
            <span
              className={cn(
                "text-[10.5px] font-semibold transition-colors",
                on ? "text-brand-600 dark:text-brand-400" : "text-zinc-400 dark:text-zinc-500"
              )}
            >
              {t.label}
            </span>
          </button>
        );
      })}
    </nav>
  );
}

export function StatusBar() {
  const [now, setNow] = useState(() => clockHHMM());
  useEffect(() => {
    const t = setInterval(() => setNow(clockHHMM()), 15000);
    return () => clearInterval(t);
  }, []);
  return (
    <div className="flex items-center justify-between bg-brand-800 px-5 pb-0.5 pt-1.5 text-[11px] font-semibold text-white">
      <span>{now}</span>
      <div className="flex items-center gap-1.5">
        <svg width="15" height="11" viewBox="0 0 16 12" fill="currentColor">
          <rect x="0" y="8" width="3" height="4" rx="1" />
          <rect x="4.3" y="5.5" width="3" height="6.5" rx="1" />
          <rect x="8.6" y="3" width="3" height="9" rx="1" />
          <rect x="12.9" y="0.5" width="3" height="11.5" rx="1" opacity="0.5" />
        </svg>
        <svg width="14" height="11" viewBox="0 0 16 12" fill="currentColor">
          <path d="M8 11.2 1 4.6A10 10 0 0 1 15 4.6L8 11.2Z" />
        </svg>
        <svg width="22" height="11" viewBox="0 0 26 12" fill="none" stroke="currentColor">
          <rect x="0.6" y="0.6" width="21" height="10.8" rx="2.6" strokeWidth="1.2" opacity="0.7" />
          <rect x="2.2" y="2.2" width="16" height="7.6" rx="1.4" fill="currentColor" />
          <path d="M23.5 4.2v3.6" strokeWidth="2.2" strokeLinecap="round" opacity="0.7" />
        </svg>
      </div>
    </div>
  );
}
