import type { SVGProps } from "react";

const paths: Record<string, string[]> = {
  home: ["M3 10.5 12 3l9 7.5", "M5 9.5V20a1 1 0 0 0 1 1h4v-6h4v6h4a1 1 0 0 0 1-1V9.5"],
  grid: [
    "M4 4h7v7H4z",
    "M13 4h7v7h-7z",
    "M4 13h7v7H4z",
    "M13 13h7v7h-7z",
  ],
  play: ["M6 4.5v15l13-7.5-13-7.5Z"],
  bookmark: ["M6 3h12a1 1 0 0 1 1 1v17l-7-4-7 4V4a1 1 0 0 1 1-1Z"],
  menu: ["M4 7h16", "M4 12h16", "M4 17h16"],
  search: ["M11 4a7 7 0 1 0 0 14 7 7 0 0 0 0-14Z", "m20 20-4.2-4.2"],
  bell: [
    "M18 15v-4a6 6 0 1 0-12 0v4l-2 3h16l-2-3Z",
    "M10 21a2 2 0 0 0 4 0",
  ],
  sun: [
    "M12 7a5 5 0 1 0 0 10 5 5 0 0 0 0-10Z",
    "M12 2v2M12 20v2M2 12h2M20 12h2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M19.1 4.9l-1.4 1.4M6.3 17.7l-1.4 1.4",
  ],
  moon: ["M20 14.5A8.5 8.5 0 0 1 9.5 4a8.5 8.5 0 1 0 10.5 10.5Z"],
  share: [
    "M18 8a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5Z",
    "M6 14.5a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5Z",
    "M18 21a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5Z",
    "m8.2 10.8 7.6-4.1M8.2 13.2l7.6 4.1",
  ],
  back: ["M15 5l-7 7 7 7"],
  chevron: ["M9 5l7 7-7 7"],
  chevronDown: ["M6 9l6 6 6-6"],
  eye: ["M2 12s3.6-6 10-6 10 6 10 6-3.6 6-10 6-10-6-10-6Z", "M12 14.5a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5Z"],
  comment: ["M21 12a8 8 0 0 1-11.6 7.1L4 20.5l1.4-5A8 8 0 1 1 21 12Z"],
  clock: ["M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18Z", "M12 7v5l3.5 2"],
  close: ["M6 6l12 12", "M18 6 6 18"],
  check: ["M5 12.5 10 17 19 7"],
  refresh: ["M20 11a8 8 0 1 0-1.6 6", "M20 5v6h-6"],
  text: ["M4 19 9 5l5 14", "M5.8 15h6.4", "M16 19l3-8 3 8", "M17 16.5h4"],
  download: ["M12 4v11", "m7.5 11 4.5 4.5L16.5 11", "M5 20h14"],
  globe: ["M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18Z", "M3.5 9h17M3.5 15h17", "M12 3c2.5 2.6 3.8 5.7 3.8 9S14.5 18.4 12 21c-2.5-2.6-3.8-5.7-3.8-9S9.5 5.6 12 3Z"],
  settings: [
    "M12 15.5a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7Z",
    "M19.4 14a1.6 1.6 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.6 1.6 0 0 0-2.7 1.1v.3a2 2 0 1 1-4 0v-.2a1.6 1.6 0 0 0-2.8-1.1l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1A1.6 1.6 0 0 0 3.5 13h-.3a2 2 0 1 1 0-4h.2a1.6 1.6 0 0 0 1.1-2.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1A1.6 1.6 0 0 0 10 3.5v-.3a2 2 0 1 1 4 0v.2a1.6 1.6 0 0 0 2.7 1.1l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.6 1.6 0 0 0 1.1 2.7h.3a2 2 0 1 1 0 4h-.2a1.6 1.6 0 0 0-1.3 1Z",
  ],
  info: ["M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18Z", "M12 11v5", "M12 7.6v.1"],
  mail: ["M3 6h18v12H3z", "m3.5 7 8.5 6 8.5-6"],
  phone: ["M6.5 3h3l1.5 4-2 1.5a12 12 0 0 0 5.5 5.5L16 12l4 1.5v3A2.5 2.5 0 0 1 17.3 19 15.5 15.5 0 0 1 5 6.7 2.5 2.5 0 0 1 6.5 3Z"],
  shield: ["M12 3 5 6v6c0 4.3 3 7.6 7 9 4-1.4 7-4.7 7-9V6l-7-3Z", "m9 12 2 2 4-4"],
  star: ["m12 3.5 2.6 5.4 5.9.8-4.3 4.1 1 5.9-5.2-2.8-5.2 2.8 1-5.9L3.5 9.7l5.9-.8L12 3.5Z"],
  trash: ["M4 7h16", "M9 7V4h6v3", "M6 7l1 13h10l1-13"],
  external: ["M14 4h6v6", "M20 4 10 14", "M18 14v5a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1h5"],
  fire: ["M12 3s5 4 5 8a5 5 0 1 1-10 0c0-1.6.8-3 1.6-4 .3 1.2 1 2 1.9 2 1 0 1.5-1 1.5-2.6V3Z"],
  wifiOff: ["M3 3l18 18", "M5 12.5a11 11 0 0 1 4-2.6", "M2 8.8A16 16 0 0 1 9 5.4", "M15 5.5a16 16 0 0 1 7 3.3", "M15.5 10.4a11 11 0 0 1 3.5 2.1", "M9 16.2a6 6 0 0 1 6 0", "M12 20h.01"],
  user: ["M12 12a4 4 0 1 0 0-8 4 4 0 0 0 0 8Z", "M4.5 20a7.5 7.5 0 0 1 15 0"],
  location: ["M12 21s7-5.5 7-11a7 7 0 1 0-14 0c0 5.5 7 11 7 11Z", "M12 12.5a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5Z"],
  copy: ["M9 9h10v12H9z", "M5 15H4a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1h10a1 1 0 0 1 1 1v1"],
  epaper: ["M4 5h16v14H4z", "M8 9h8M8 13h8M8 17h5"],
  bolt: ["m13 2-9 12h7l-1 8 9-12h-7l1-8Z"],
  plus: ["M12 5v14", "M5 12h14"],
};

interface IconProps extends SVGProps<SVGSVGElement> {
  name: keyof typeof paths | string;
  size?: number;
  filled?: boolean;
}

export function Icon({ name, size = 22, filled, className, ...rest }: IconProps) {
  const d = paths[name] ?? paths.info;
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill={filled ? "currentColor" : "none"}
      stroke="currentColor"
      strokeWidth={1.8}
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
      {...rest}
    >
      {d.map((p, i) => (
        <path key={i} d={p} />
      ))}
    </svg>
  );
}

export function Logo({ size = 36 }: { size?: number }) {
  return (
    <div
      className="relative grid shrink-0 place-items-center rounded-xl bg-gradient-to-br from-brand-500 via-brand-600 to-brand-800 font-bold text-white shadow-lg shadow-brand-900/30 ring-1 ring-white/25"
      style={{ width: size, height: size, fontSize: size * 0.46 }}
    >
      <span className="translate-y-[-1px] font-bangla">চাঁ</span>
      <span className="absolute -right-0.5 -top-0.5 h-2 w-2 rounded-full bg-amber-300 ring-2 ring-brand-800" />
    </div>
  );
}
