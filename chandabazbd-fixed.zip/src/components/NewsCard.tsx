import { useEffect, useState } from "react";
import type { Post } from "@/lib/api";
import { formatViews, timeAgo } from "@/lib/utils";
import { useApp } from "@/lib/store";
import { Icon } from "./Icons";
import { cn } from "@/utils/cn";
import { sourceById } from "@/lib/world";
import { catStyle } from "@/data/catMeta";

interface Props {
  post: Post;
  onOpen: (p: Post) => void;
  variant?: "hero" | "list" | "big" | "compact" | "number";
  index?: number;
}

const FALLBACK_BG = [
  "from-brand-700 to-brand-500",
  "from-indigo-700 to-indigo-500",
  "from-teal-700 to-teal-500",
  "from-amber-700 to-amber-500",
  "from-rose-700 to-rose-500",
];

export function Thumb({
  post,
  className,
  rounded = "rounded-xl",
}: {
  post: Post;
  className?: string;
  rounded?: string;
}) {
  const [broken, setBroken] = useState(false);
  const idx = post.id.length % FALLBACK_BG.length;

  useEffect(() => setBroken(false), [post.image]);

  if (!post.image || broken) {
    return (
      <div
        className={cn(
          "grid place-items-center bg-gradient-to-br text-white/90",
          FALLBACK_BG[idx],
          rounded,
          className
        )}
      >
        <span className="px-2 text-center text-[10px] font-bold leading-tight opacity-90">
          {post.source}
        </span>
      </div>
    );
  }
  return (
    <img
      src={post.image}
      alt=""
      loading="lazy"
      referrerPolicy="no-referrer"
      onError={() => setBroken(true)}
      className={cn("bg-zinc-100 object-cover dark:bg-ink-700", rounded, className)}
    />
  );
}

function Pill({ post, solid }: { post: Post; solid?: boolean }) {
  const label = post.catNames[0] ?? post.source;
  const s = catStyle(label);
  return (
    <span
      className={cn(
        "inline-block max-w-[46%] truncate rounded px-1.5 py-0.5 text-[10.5px] font-semibold leading-tight align-middle",
        solid && "text-white"
      )}
      style={
        solid
          ? { background: s.color }
          : { color: s.color, background: `color-mix(in srgb, ${s.color} 14%, transparent)` }
      }
    >
      {label}
    </span>
  );
}

function SourceBadge({ post }: { post: Post }) {
  if (!post.external) return null;
  const src = sourceById(post.sourceId);
  return (
    <span
      className="inline-flex items-center gap-1 rounded px-1.5 py-0.5 text-[10px] font-bold text-white"
      style={{ background: src?.color ?? "#475569" }}
    >
      <Icon name="globe" size={9} />
      {post.source}
    </span>
  );
}

export function SaveButton({ post, className }: { post: Post; className?: string }) {
  const { isSaved, toggleSave } = useApp();
  const saved = isSaved(post.id);
  return (
    <button
      onClick={(e) => {
        e.stopPropagation();
        toggleSave(post);
      }}
      className={cn(
        "grid h-7 w-7 place-items-center rounded-full transition active:scale-90",
        saved ? "text-brand-600 dark:text-brand-400" : "text-zinc-400 dark:text-zinc-500",
        className
      )}
      aria-label="সংরক্ষণ"
    >
      <Icon name="bookmark" size={16} filled={saved} />
    </button>
  );
}

export default function NewsCard({ post, onOpen, variant = "list", index }: Props) {
  const { dataSaver } = useApp();
  const showImg = !dataSaver;

  if (variant === "hero") {
    return (
      <button
        onClick={() => onOpen(post)}
        className="relative h-56 w-full overflow-hidden rounded-2xl bg-zinc-800 text-left shadow-lg active:scale-[0.99]"
      >
        <Thumb post={post} rounded="rounded-2xl" className="h-full w-full" />
        <div className="absolute inset-0 bg-gradient-to-t from-black/92 via-black/35 to-transparent" />
        <div className="absolute inset-x-0 bottom-0 p-4">
          <div className="mb-2 flex flex-wrap items-center gap-1.5">
            <Pill post={post} solid />
            <SourceBadge post={post} />
            <span className="text-[11px] text-white/80">{timeAgo(post.minutesAgo)}</span>
          </div>
          <h3 className="font-serif-bn line-clamp-3 text-[17px] font-bold leading-snug text-white drop-shadow">
            {post.title}
          </h3>
        </div>
      </button>
    );
  }

  if (variant === "big") {
    return (
      <button
        onClick={() => onOpen(post)}
        className="w-full overflow-hidden rounded-2xl bg-white text-left shadow-sm ring-1 ring-zinc-200/70 active:scale-[0.99] dark:bg-ink-800 dark:ring-ink-700"
      >
        {showImg && (
          <div className="relative h-44 w-full overflow-hidden bg-zinc-100 dark:bg-ink-700">
            <Thumb post={post} rounded="rounded-none" className="h-full w-full" />
            <span className="absolute left-3 top-3 flex gap-1.5">
              <Pill post={post} solid />
              <SourceBadge post={post} />
            </span>
          </div>
        )}
        <div className="p-3.5">
          <h3 className="font-serif-bn line-clamp-3 text-[16px] font-bold leading-snug text-zinc-900 dark:text-zinc-50">
            {post.title}
          </h3>
          <p className="mt-1.5 line-clamp-2 text-[13px] leading-relaxed text-zinc-500 dark:text-zinc-400">
            {post.excerpt}
          </p>
          <div className="mt-2.5 flex items-center justify-between text-[11.5px] text-zinc-400 dark:text-zinc-500">
            <span className="flex items-center gap-1">
              <Icon name="clock" size={12} /> {timeAgo(post.minutesAgo)}
            </span>
            <span className="flex items-center gap-3">
              <span>{post.source}</span>
              <SaveButton post={post} />
            </span>
          </div>
        </div>
      </button>
    );
  }

  if (variant === "compact") {
    return (
      <button
        onClick={() => onOpen(post)}
        className="w-60 shrink-0 overflow-hidden rounded-xl bg-white text-left shadow-sm ring-1 ring-zinc-200/70 active:scale-[0.98] dark:bg-ink-800 dark:ring-ink-700"
      >
        {showImg && (
          <div className="h-28 w-full overflow-hidden bg-zinc-100 dark:bg-ink-700">
            <Thumb post={post} rounded="rounded-none" className="h-full w-full" />
          </div>
        )}
        <div className="p-3">
          <div className="flex flex-wrap gap-1">
            <Pill post={post} />
            <SourceBadge post={post} />
          </div>
          <h3 className="mt-1.5 line-clamp-3 text-[13.5px] font-semibold leading-snug text-zinc-900 dark:text-zinc-50">
            {post.title}
          </h3>
          <span className="mt-1.5 block text-[11px] text-zinc-400">
            {timeAgo(post.minutesAgo)}
          </span>
        </div>
      </button>
    );
  }

  if (variant === "number") {
    return (
      <button
        onClick={() => onOpen(post)}
        className="flex w-full items-start gap-3 px-4 py-3 text-left active:bg-zinc-50 dark:active:bg-ink-800"
      >
        <span className="w-6 shrink-0 bg-gradient-to-b from-brand-500 to-brand-700 bg-clip-text text-[22px] font-extrabold leading-none text-transparent">
          {["১", "২", "৩", "৪", "৫", "৬", "৭", "৮", "৯", "১০"][(index ?? 0) % 10]}
        </span>
        <div className="min-w-0 flex-1">
          <h3 className="line-clamp-2 text-[14px] font-semibold leading-snug text-zinc-900 dark:text-zinc-50">
            {post.title}
          </h3>
          <div className="mt-1 flex flex-wrap items-center gap-1.5 text-[11px] text-zinc-400">
            <Pill post={post} />
            <span>{timeAgo(post.minutesAgo)}</span>
          </div>
        </div>
      </button>
    );
  }

  return (
    <button
      onClick={() => onOpen(post)}
      className="flex w-full items-start gap-3 px-4 py-3 text-left active:bg-zinc-50 dark:active:bg-ink-800/60"
    >
      {showImg && (
        <div className="relative h-[74px] w-[104px] shrink-0 overflow-hidden rounded-xl bg-zinc-100 dark:bg-ink-700">
          <Thumb post={post} className="h-full w-full" />
        </div>
      )}
      <div className="min-w-0 flex-1">
        <div className="flex flex-wrap items-center gap-1">
          <Pill post={post} />
          <SourceBadge post={post} />
        </div>
        <h3 className="mt-1 line-clamp-3 text-[14.5px] font-semibold leading-snug text-zinc-900 dark:text-zinc-50">
          {post.title}
        </h3>
        <div className="mt-1.5 flex items-center justify-between">
          <span className="flex items-center gap-1 text-[11px] text-zinc-400 dark:text-zinc-500">
            <Icon name="clock" size={11} /> {timeAgo(post.minutesAgo)}
            {post.readMinutes > 0 && <span>· {formatViews(post.readMinutes)} মিনিট পড়া</span>}
          </span>
          <SaveButton post={post} />
        </div>
      </div>
    </button>
  );
}
