import type { Post } from "@/lib/api";
import { Sheet } from "./ui";
import { timeAgo } from "@/lib/utils";
import { cn } from "@/utils/cn";
import { Thumb } from "./NewsCard";

export interface Notif {
  id: string;
  post: Post;
  type: "breaking" | "world" | "update";
  read: boolean;
}

const meta: Record<Notif["type"], { label: string; icon: string; color: string }> = {
  breaking: { label: "সর্বশেষ সংবাদ", icon: "⚡", color: "#de1f26" },
  world: { label: "আন্তর্জাতিক", icon: "🌍", color: "#0891b2" },
  update: { label: "আপডেট", icon: "📰", color: "#7c3aed" },
};

export default function NotificationsSheet({
  open,
  onClose,
  notifs,
  onReadAll,
  onOpen,
}: {
  open: boolean;
  onClose: () => void;
  notifs: Notif[];
  onReadAll: () => void;
  onOpen: (p: Post) => void;
}) {
  return (
    <Sheet open={open} onClose={onClose} title="নোটিফিকেশন">
      {notifs.length > 0 ? (
        <>
          <div className="flex justify-end">
            <button onClick={onReadAll} className="text-[12px] font-semibold text-brand-600">
              সব পড়া হয়েছে চিহ্নিত করুন
            </button>
          </div>
          <div className="mt-2 space-y-2 pb-2">
            {notifs.map((n) => {
              const m = meta[n.type];
              return (
                <button
                  key={n.id}
                  onClick={() => {
                    onClose();
                    onOpen(n.post);
                  }}
                  className={cn(
                    "flex w-full gap-3 rounded-xl p-2.5 text-left transition active:scale-[0.99]",
                    n.read ? "bg-zinc-50 dark:bg-ink-700/40" : "bg-brand-50 dark:bg-ink-700"
                  )}
                >
                  <span className="h-12 w-12 shrink-0 overflow-hidden rounded-xl">
                    <Thumb post={n.post} className="h-full w-full" />
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className="flex items-center gap-2">
                      <span className="text-[11px] font-bold" style={{ color: m.color }}>
                        {m.icon} {m.label}
                      </span>
                      <span className="text-[10.5px] text-zinc-400">
                        {timeAgo(n.post.minutesAgo)}
                      </span>
                      {!n.read && <span className="h-1.5 w-1.5 rounded-full bg-brand-600" />}
                    </span>
                    <span className="mt-0.5 line-clamp-2 block text-[12.5px] font-semibold leading-snug text-zinc-800 dark:text-zinc-100">
                      {n.post.title}
                    </span>
                  </span>
                </button>
              );
            })}
          </div>
        </>
      ) : (
        <p className="py-10 text-center text-[13px] text-zinc-400">
          এখনো কোনো নোটিফিকেশন নেই
        </p>
      )}
    </Sheet>
  );
}
