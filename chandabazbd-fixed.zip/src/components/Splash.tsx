import { Logo } from "./Icons";
import { toBn } from "@/lib/utils";

export default function Splash({ hiding }: { hiding: boolean }) {
  return (
    <div
      className={`absolute inset-0 z-[90] flex flex-col items-center justify-center bg-gradient-to-br from-brand-800 via-brand-700 to-ink-900 transition-all duration-500 ${
        hiding ? "pointer-events-none scale-110 opacity-0" : "opacity-100"
      }`}
    >
      <div className="animate-pop-in flex flex-col items-center">
        <Logo size={84} />
        <h1 className="mt-5 font-serif-bn text-[29px] font-bold tracking-tight text-white">
          চাঁন্দাবাজ বিডি
        </h1>
        <p className="mt-1 px-10 text-center text-[12.5px] font-medium leading-relaxed text-white/70">
          সত্য ও বস্তুনিষ্ঠ সংবাদ পরিবেশনে প্রতিশ্রুতিবদ্ধ
        </p>
      </div>

      <div className="absolute bottom-16 flex flex-col items-center gap-3">
        <div className="h-1 w-32 overflow-hidden rounded-full bg-white/20">
          <div className="animate-loading-bar h-full w-1/3 rounded-full bg-white/80" />
        </div>
        <p className="text-[11px] text-white/50">
          সংস্করণ {toBn("2.0.0")} · chandabazbd.com
        </p>
      </div>
    </div>
  );
}
