import { useEffect, useRef, useState } from "react";
import type { Video } from "@/lib/youtube";
import { channelById } from "@/lib/youtube";
import { Icon } from "@/components/Icons";
import { banglaShortDate, clockHHMM, timeAgo } from "@/lib/utils";

/* YouTube IFrame Player API লোডার (একবারই লোড হয়) */
type YTApi = { Player: new (el: HTMLElement, opts: Record<string, unknown>) => YTPlayer };
interface YTPlayer {
  destroy: () => void;
  playVideo: () => void;
}
let apiPromise: Promise<YTApi> | null = null;

function loadYT(): Promise<YTApi> {
  const w = window as unknown as {
    YT?: YTApi;
    onYouTubeIframeAPIReady?: () => void;
  };
  if (w.YT?.Player) return Promise.resolve(w.YT);
  if (apiPromise) return apiPromise;
  apiPromise = new Promise<YTApi>((resolve, reject) => {
    const prev = w.onYouTubeIframeAPIReady;
    w.onYouTubeIframeAPIReady = () => {
      prev?.();
      if (w.YT) resolve(w.YT);
    };
    const s = document.createElement("script");
    s.src = "https://www.youtube.com/iframe_api";
    s.async = true;
    s.onerror = () => {
      apiPromise = null;
      reject(new Error("yt-api"));
    };
    document.head.appendChild(s);
  });
  return apiPromise;
}

export default function VideoPlayer({ video, onBack }: { video: Video; onBack: () => void }) {
  const box = useRef<HTMLDivElement>(null);
  const [error, setError] = useState<"offline" | "blocked" | null>(null);
  const [ready, setReady] = useState(false);
  const ch = channelById(video.channelKey);

  useEffect(() => {
    let player: YTPlayer | null = null;
    let alive = true;
    setError(null);
    setReady(false);

    loadYT()
      .then((YT) => {
        if (!alive || !box.current) return;
        // React-এর নিজস্ব নোডের বদলে আলাদা হোস্ট নোড, যাতে destroy() নিরাপদ থাকে
        const host = document.createElement("div");
        box.current.appendChild(host);
        player = new YT.Player(host, {
          videoId: video.id,
          width: "100%",
          height: "100%",
          playerVars: {
            playsinline: 1, // ফুলস্ক্রিন নেটিভ প্লেয়ার দখল না নিয়ে অ্যাপের ভেতরেই চলবে
            autoplay: 1,
            rel: 0,
            modestbranding: 1,
            fs: 1,
          },
          events: {
            onReady: (e: { target: YTPlayer }) => {
              setReady(true);
              e.target.playVideo();
            },
            onError: (e: { data: number }) => {
              // ১০১/১৫০ = মালিক এমবেড বন্ধ রেখেছেন
              if (alive) setError(e.data === 101 || e.data === 150 ? "blocked" : "offline");
            },
          },
        });
      })
      .catch(() => alive && setError("offline"));

    return () => {
      alive = false;
      try {
        player?.destroy();
      } catch {
        /* ignore */
      }
    };
  }, [video.id]);

  return (
    <div className="animate-screen-in flex h-full flex-col bg-black text-white">
      <div className="flex items-center gap-1 px-2 py-2">
        <button
          onClick={onBack}
          className="grid h-9 w-9 place-items-center rounded-full active:bg-white/10"
          aria-label="ফিরে যান"
        >
          <Icon name="back" size={20} />
        </button>
        <span className="flex-1 truncate text-[13px] font-bold">{video.channelName}</span>
        <button
          onClick={onBack}
          className="grid h-9 w-9 place-items-center rounded-full active:bg-white/10"
          aria-label="বন্ধ করুন"
        >
          <Icon name="close" size={19} />
        </button>
      </div>

      <div className="relative aspect-video w-full bg-zinc-950">
        <div ref={box} className="absolute inset-0 [&_iframe]:h-full [&_iframe]:w-full" />
        {!ready && !error && (
          <div className="absolute inset-0 grid place-items-center">
            <div className="h-9 w-9 animate-spin rounded-full border-2 border-white/20 border-t-white" />
          </div>
        )}
        {error && (
          <div className="absolute inset-0 grid place-items-center bg-zinc-950 p-5 text-center">
            <div>
              <p className="text-[13px] font-semibold">
                {error === "blocked"
                  ? "এই ভিডিওটি অ্যাপের ভেতরে চালানোর অনুমতি চ্যানেল দেয়নি।"
                  : "ভিডিও চালানো যায়নি। ইন্টারনেট সংযোগ পরীক্ষা করুন।"}
              </p>
              {error === "blocked" && (
                <a
                  href={`https://www.youtube.com/watch?v=${video.id}`}
                  target="_blank"
                  rel="noreferrer"
                  className="mt-3 inline-flex items-center gap-1.5 rounded-lg bg-white/15 px-4 py-2 text-[12.5px] font-bold"
                >
                  <Icon name="external" size={14} /> YouTube-এ দেখুন
                </a>
              )}
            </div>
          </div>
        )}
      </div>

      <div className="no-scrollbar flex-1 overflow-y-auto px-4 py-4">
        <h1 className="font-serif-bn text-[18px] font-bold leading-snug">{video.title}</h1>
        <div className="mt-3 flex items-center gap-2.5">
          <div
            className="grid h-9 w-9 shrink-0 place-items-center rounded-full text-[11px] font-bold text-white"
            style={{ background: ch?.color ?? "#475569" }}
          >
            {ch?.short ?? "YT"}
          </div>
          <div className="leading-tight">
            <p className="text-[12.5px] font-semibold">{video.channelName}</p>
            <p className="text-[11px] text-white/55">
              {banglaShortDate(new Date(video.publishedISO))} ·{" "}
              {clockHHMM(new Date(video.publishedISO))} · {timeAgo(video.minutesAgo)}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
