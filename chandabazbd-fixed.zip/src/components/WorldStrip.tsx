import { useEffect, useState } from "react";
import type { Post } from "@/lib/api";
import { cachedWorldNews, fetchWorldNews } from "@/lib/world";
import { useApp } from "@/lib/store";
import NewsCard from "./NewsCard";
import { SectionHeader } from "./ui";

export default function WorldStrip({
  onOpen,
  onSeeAll,
}: {
  onOpen: (p: Post) => void;
  onSeeAll: () => void;
}) {
  const { worldSources } = useApp();
  const ids = worldSources.slice(0, 3);
  const [posts, setPosts] = useState<Post[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let alive = true;
    cachedWorldNews(ids).then((c) => {
      if (alive && c.length) setPosts((prev) => (prev.length ? prev : c.slice(0, 10)));
    });
    fetchWorldNews(ids)
      .then(({ posts: p }) => {
        if (!alive) return;
        if (p.length) setPosts(p.slice(0, 10));
        setLoading(false);
      })
      .catch(() => alive && setLoading(false));
    return () => {
      alive = false;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [worldSources.join(",")]);

  if (!loading && !posts.length) return null;

  return (
    <div className="mt-5">
      <SectionHeader
        title="🌍 আন্তর্জাতিক সংবাদ"
        accent="#0891b2"
        action="সব দেখুন"
        onAction={onSeeAll}
      />
      <div className="no-scrollbar flex gap-3 overflow-x-auto px-4 pb-1">
        {loading
          ? [0, 1, 2].map((i) => (
              <div
                key={i}
                className="shimmer relative h-[190px] w-60 shrink-0 overflow-hidden rounded-xl bg-zinc-200 dark:bg-ink-700"
              />
            ))
          : posts.map((p) => <NewsCard key={p.id} post={p} onOpen={onOpen} variant="compact" />)}
      </div>
    </div>
  );
}
