import { useEffect, type ReactNode } from "react";
import { cn } from "@/utils/cn";
import { Icon } from "./Icons";
import { useApp } from "@/lib/store";

export function Toasts() {
  const { toasts } = useApp();
  return (
    <div className="pointer-events-none absolute inset-x-0 bottom-24 z-[70] flex flex-col items-center gap-2 px-6">
      {toasts.map((t) => (
        <div
          key={t.id}
          className="animate-slide-up flex max-w-full items-center gap-2 rounded-full bg-zinc-900/95 px-4 py-2.5 text-[13px] font-medium text-white shadow-xl ring-1 ring-white/10 backdrop-blur dark:bg-zinc-100/95 dark:text-zinc-900"
        >
          {t.icon && <span>{t.icon}</span>}
          <span className="truncate">{t.msg}</span>
        </div>
      ))}
    </div>
  );
}

export function Switch({
  checked,
  onChange,
}: {
  checked: boolean;
  onChange: (v: boolean) => void;
}) {
  return (
    <button
      type="button"
      onClick={() => onChange(!checked)}
      className={cn(
        "relative h-[26px] w-[46px] shrink-0 rounded-full transition-colors duration-300",
        checked ? "bg-brand-600" : "bg-zinc-300 dark:bg-ink-600"
      )}
      aria-pressed={checked}
    >
      <span
        className={cn(
          "absolute top-[3px] h-5 w-5 rounded-full bg-white shadow transition-all duration-300",
          checked ? "left-[23px]" : "left-[3px]"
        )}
      />
    </button>
  );
}

export function Sheet({
  open,
  onClose,
  title,
  children,
}: {
  open: boolean;
  onClose: () => void;
  title: string;
  children: ReactNode;
}) {
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onClose]);

  if (!open) return null;
  return (
    <div className="absolute inset-0 z-[60]">
      <div
        className="absolute inset-0 bg-black/50 backdrop-blur-[2px]"
        onClick={onClose}
        role="presentation"
      />
      <div className="animate-sheet-in absolute inset-x-0 bottom-0 max-h-[78%] overflow-y-auto rounded-t-3xl bg-white pb-6 shadow-2xl dark:bg-ink-800">
        <div className="sticky top-0 z-10 flex items-center justify-between rounded-t-3xl bg-white/95 px-5 pb-3 pt-3 backdrop-blur dark:bg-ink-800/95">
          <div className="absolute left-1/2 top-1.5 h-1 w-10 -translate-x-1/2 rounded-full bg-zinc-300 dark:bg-ink-600" />
          <h3 className="mt-2 text-[15px] font-semibold text-zinc-900 dark:text-zinc-100">
            {title}
          </h3>
          <button
            onClick={onClose}
            className="mt-2 grid h-8 w-8 place-items-center rounded-full bg-zinc-100 text-zinc-500 dark:bg-ink-700 dark:text-zinc-400"
          >
            <Icon name="close" size={16} />
          </button>
        </div>
        <div className="px-5">{children}</div>
      </div>
    </div>
  );
}

export function SectionHeader({
  title,
  accent,
  action,
  onAction,
}: {
  title: string;
  accent?: string;
  action?: string;
  onAction?: () => void;
}) {
  return (
    <div className="mb-3 flex items-end justify-between px-4">
      <div className="flex items-center gap-2">
        <span
          className="h-5 w-1.5 rounded-full"
          style={{ background: accent ?? "var(--color-brand-600)" }}
        />
        <h2 className="text-[17px] font-bold leading-none text-zinc-900 dark:text-zinc-50">
          {title}
        </h2>
      </div>
      {action && (
        <button
          onClick={onAction}
          className="flex items-center gap-0.5 text-[12.5px] font-semibold text-brand-600 dark:text-brand-400"
        >
          {action}
          <Icon name="chevron" size={13} />
        </button>
      )}
    </div>
  );
}

export function SkeletonCard() {
  return (
    <div className="flex gap-3 px-4 py-3">
      <div className="shimmer relative h-20 w-28 shrink-0 overflow-hidden rounded-xl bg-zinc-200 dark:bg-ink-700" />
      <div className="flex-1 space-y-2 py-1">
        <div className="shimmer relative h-3 w-16 overflow-hidden rounded bg-zinc-200 dark:bg-ink-700" />
        <div className="shimmer relative h-3.5 w-full overflow-hidden rounded bg-zinc-200 dark:bg-ink-700" />
        <div className="shimmer relative h-3.5 w-3/4 overflow-hidden rounded bg-zinc-200 dark:bg-ink-700" />
      </div>
    </div>
  );
}

export function EmptyState({
  icon,
  title,
  text,
  actionLabel,
  onAction,
}: {
  icon: string;
  title: string;
  text: string;
  actionLabel?: string;
  onAction?: () => void;
}) {
  return (
    <div className="flex flex-col items-center justify-center px-10 py-16 text-center">
      <div className="mb-4 grid h-20 w-20 place-items-center rounded-3xl bg-brand-50 text-4xl dark:bg-ink-700">
        {icon}
      </div>
      <h3 className="text-[16px] font-bold text-zinc-800 dark:text-zinc-100">{title}</h3>
      <p className="mt-1.5 text-[13px] leading-relaxed text-zinc-500 dark:text-zinc-400">{text}</p>
      {actionLabel && (
        <button
          onClick={onAction}
          className="mt-5 rounded-full bg-brand-600 px-5 py-2.5 text-[13px] font-semibold text-white shadow-lg shadow-brand-600/25 active:scale-95"
        >
          {actionLabel}
        </button>
      )}
    </div>
  );
}
