/** ক্যাটাগরির নাম/স্লাগ → আইকন ও রঙ (chandabazbd.com-এর আসল বিভাগ অনুযায়ী) */

interface Meta {
  icon: string;
  color: string;
}

const BY_SLUG: Record<string, Meta> = {
  politics: { icon: "🏛️", color: "#1d4ed8" },
  national: { icon: "🇧🇩", color: "#047857" },
  "middle-east": { icon: "🕌", color: "#b45309" },
  world: { icon: "🌍", color: "#0891b2" },
  nationwide: { icon: "🗺️", color: "#7c3aed" },
  america: { icon: "🗽", color: "#334155" },
  economy: { icon: "📈", color: "#b45309" },
  trade: { icon: "💹", color: "#0f766e" },
  india: { icon: "🇮🇳", color: "#ea580c" },
  localnews: { icon: "📍", color: "#65a30d" },
  extortion: { icon: "🚨", color: "#b91c1c" },
  qater: { icon: "🇶🇦", color: "#7e22ce" },
  "public-suffering": { icon: "😣", color: "#be123c" },
  media: { icon: "📡", color: "#0369a1" },
  "literature-and-culture": { icon: "📖", color: "#9333ea" },
  "rural-electricity": { icon: "💡", color: "#ca8a04" },
  citizenservice: { icon: "🤝", color: "#0d9488" },
  ourfamily: { icon: "👨‍👩‍👧", color: "#db2777" },
  terrorist: { icon: "⚠️", color: "#991b1b" },
  game: { icon: "🏏", color: "#15803d" },
  islam: { icon: "☪️", color: "#047857" },
  entertainment: { icon: "🎬", color: "#be185d" },
  exile: { icon: "✈️", color: "#0284c7" },
};

const BY_NAME: Record<string, Meta> = {
  রাজনীতি: BY_SLUG.politics,
  জাতীয়: BY_SLUG.national,
  মধ্যপ্রাচ্য: BY_SLUG["middle-east"],
  বিশ্ব: BY_SLUG.world,
  সারাদেশ: BY_SLUG.nationwide,
  আমেরিকা: BY_SLUG.america,
  অর্থনীতি: BY_SLUG.economy,
  বাণিজ্য: BY_SLUG.trade,
  ভারত: BY_SLUG.india,
  "স্থানীয় সংবাদ": BY_SLUG.localnews,
  চাঁদাবাজি: BY_SLUG.extortion,
  কাতার: BY_SLUG.qater,
  জনদুর্ভোগ: BY_SLUG["public-suffering"],
  মিডিয়া: BY_SLUG.media,
  ফুটবল: { icon: "⚽", color: "#16a34a" },
  খেলা: BY_SLUG.game,
  ইসলাম: BY_SLUG.islam,
  বিনোদন: BY_SLUG.entertainment,
  ভ্রমণ: { icon: "🧳", color: "#0891b2" },
  প্রবাস: BY_SLUG.exile,
  "প্রবাসী নিউজ": { icon: "🌐", color: "#4f46e5" },
  "সাহিত্য ও সংস্কৃতি": BY_SLUG["literature-and-culture"],
  "পল্লী বিদ্যুৎ": BY_SLUG["rural-electricity"],
  "নাগরিক সেবা": BY_SLUG.citizenservice,
  "আমাদের পরিবার": BY_SLUG.ourfamily,
  জঙ্গি: BY_SLUG.terrorist,
  আন্তর্জাতিক: { icon: "🌍", color: "#0891b2" },
  International: { icon: "🌍", color: "#0891b2" },
  সর্বশেষ: { icon: "⚡", color: "#de1f26" },
};

const PALETTE = ["#de1f26", "#1d4ed8", "#047857", "#b45309", "#7c3aed", "#0891b2", "#be185d"];

const hash = (s: string) => {
  let h = 0;
  for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) >>> 0;
  return h;
};

export const catStyle = (nameOrSlug: string): Meta => {
  const key = (nameOrSlug ?? "").trim();
  return (
    BY_NAME[key] ??
    BY_SLUG[key] ?? { icon: "📰", color: PALETTE[hash(key) % PALETTE.length] }
  );
};
