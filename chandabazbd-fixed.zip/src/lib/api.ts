/**
 * chandabazbd.com — লাইভ কনটেন্ট API ক্লায়েন্ট
 * ----------------------------------------------
 * দুটি উৎস ব্যবহার করা হয়:
 *  1) WordPress REST (wp/v2)        → দ্রুত, হালকা তালিকা (_fields দিয়ে)
 *  (কোনো গোপন কী অ্যাপে রাখা হয় না — সব পাবলিক WP REST এন্ডপয়েন্ট)
 */

import { getItem, setItem } from "./db";

export const SITE = "https://chandabazbd.com";

export interface Post {
  id: string;
  wpId?: number;
  title: string;
  excerpt: string;
  html?: string;
  image: string | null;
  dateISO: string;
  minutesAgo: number;
  link: string;
  catIds: number[];
  catNames: string[];
  source: string;
  sourceId: string;
  external: boolean;
  readMinutes: number;
}

export interface WpCategory {
  id: number;
  name: string;
  slug: string;
  count: number;
}

/* ------------------------------------------------------------------ */
/* helpers                                                             */
/* ------------------------------------------------------------------ */

const PROXIES = [
  (u: string) => `https://api.allorigins.win/raw?url=${encodeURIComponent(u)}`,
  (u: string) => `https://api.codetabs.com/v1/proxy?quest=${encodeURIComponent(u)}`,
];

const timeout = (ms: number) => {
  const c = new AbortController();
  setTimeout(() => c.abort(), ms);
  return c.signal;
};

/** সরাসরি চেষ্টা, ব্যর্থ হলে CORS প্রক্সি দিয়ে পুনরায় */
export async function resilientFetch(
  url: string,
  init: RequestInit = {},
  ms = 14000
): Promise<Response> {
  try {
    const r = await fetch(url, { ...init, signal: timeout(ms) });
    if (r.ok) return r;
    throw new Error(`HTTP ${r.status}`);
  } catch {
    for (const make of PROXIES) {
      try {
        const r = await fetch(make(url), { signal: timeout(ms) });
        if (r.ok) return r;
      } catch {
        /* next */
      }
    }
    throw new Error("network");
  }
}

export const decodeEntities = (s: string): string =>
  s
    .replace(/&#(\d+);/g, (_, d) => String.fromCharCode(Number(d)))
    .replace(/&#x([0-9a-f]+);/gi, (_, h) => String.fromCharCode(parseInt(h, 16)))
    .replace(/&nbsp;/g, " ")
    .replace(/&amp;/g, "&")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&quot;/g, '"')
    .replace(/&#8217;|&rsquo;/g, "'")
    .replace(/&#8216;|&lsquo;/g, "'")
    .replace(/&hellip;/g, "…");

export const stripTags = (html: string): string =>
  decodeEntities(
    html
      .replace(/<script[\s\S]*?<\/script>/gi, "")
      .replace(/<style[\s\S]*?<\/style>/gi, "")
      .replace(/<[^>]+>/g, " ")
  )
    .replace(/\s+/g, " ")
    .trim();

/** DOM-ভিত্তিক নিরাপদ HTML ক্লিনার (স্ক্রিপ্ট, ইভেন্ট হ্যান্ডলার, javascript: লিংক সরায়) */
const BLOCKED_TAGS = "script,style,link,meta,iframe,object,embed,form,input,button,base,noscript";
export const sanitizeHtml = (html: string): string => {
  try {
    const doc = new DOMParser().parseFromString(html, "text/html");
    doc.querySelectorAll(BLOCKED_TAGS).forEach((n) => n.remove());
    doc.body.querySelectorAll("*").forEach((el) => {
      for (const attr of Array.from(el.attributes)) {
        const name = attr.name.toLowerCase();
        const val = attr.value.replace(/[\u0000-\u0020]+/g, "").toLowerCase();
        if (name.startsWith("on") || name === "srcdoc") el.removeAttribute(attr.name);
        else if (
          ["href", "src", "xlink:href", "action", "formaction", "poster"].includes(name) &&
          /^(javascript|vbscript|data:text\/html)/.test(val)
        )
          el.removeAttribute(attr.name);
      }
      if (el.tagName === "IMG") {
        el.setAttribute("loading", "lazy");
        el.setAttribute("decoding", "async");
        el.removeAttribute("srcset");
        el.removeAttribute("sizes");
      }
      if (el.tagName === "A") {
        el.setAttribute("target", "_blank");
        el.setAttribute("rel", "noopener noreferrer");
      }
    });
    doc.body.querySelectorAll("figure,p").forEach((el) => {
      if (!el.textContent?.trim() && !el.querySelector("img,video,audio,picture")) el.remove();
    });
    return doc.body.innerHTML;
  } catch {
    return "";
  }
};

export const minutesSince = (iso: string): number => {
  const t = new Date(iso).getTime();
  if (Number.isNaN(t)) return 0;
  return Math.max(0, Math.round((Date.now() - t) / 60000));
};

const readingTime = (text: string) => Math.max(1, Math.round(text.length / 900));

/* ------------------------------------------------------------------ */
/* WordPress REST — তালিকা (হালকা)                                     */
/* ------------------------------------------------------------------ */

interface WpPost {
  id: number;
  date_gmt: string;
  link: string;
  title: { rendered: string };
  excerpt: { rendered: string };
  categories?: number[];
  _embedded?: { "wp:featuredmedia"?: { source_url?: string }[] };
}

const FIELDS = "id,date_gmt,link,title,excerpt,categories,_links,_embedded";

export function mapWpPost(p: WpPost, catMap: Map<number, string>): Post {
  const title = decodeEntities(p.title?.rendered ?? "").trim();
  const excerpt = stripTags(p.excerpt?.rendered ?? "").slice(0, 190);
  const media = p._embedded?.["wp:featuredmedia"]?.[0]?.source_url ?? null;
  const iso = p.date_gmt ? `${p.date_gmt}Z` : new Date().toISOString();
  const catIds = p.categories ?? [];
  return {
    id: `wp-${p.id}`,
    wpId: p.id,
    title,
    excerpt,
    image: media,
    dateISO: iso,
    minutesAgo: minutesSince(iso),
    link: p.link,
    catIds,
    catNames: catIds.map((c) => catMap.get(c)).filter(Boolean) as string[],
    source: "চাঁদাবাজ বিডি",
    sourceId: "chandabazbd",
    external: false,
    readMinutes: Math.max(2, Math.round(excerpt.length / 120)),
  };
}

export interface PostQuery {
  page?: number;
  perPage?: number;
  categoryId?: number;
  search?: string;
}

export async function fetchPosts(
  q: PostQuery,
  catMap: Map<number, string>
): Promise<{ posts: Post[]; totalPages: number }> {
  const params = new URLSearchParams({
    per_page: String(q.perPage ?? 16),
    page: String(q.page ?? 1),
    _embed: "wp:featuredmedia",
    _fields: FIELDS,
    orderby: "date",
    order: "desc",
  });
  if (q.categoryId) params.set("categories", String(q.categoryId));
  if (q.search?.trim()) params.set("search", q.search.trim());

  const res = await resilientFetch(`${SITE}/wp-json/wp/v2/posts?${params}`);
  const totalPages = Number(res.headers.get("x-wp-totalpages") ?? "1") || 1;
  const data = (await res.json()) as WpPost[];
  return { posts: data.map((p) => mapWpPost(p, catMap)), totalPages };
}

/* ------------------------------------------------------------------ */
/* ক্যাটাগরি                                                            */
/* ------------------------------------------------------------------ */

export async function fetchCategories(): Promise<WpCategory[]> {
  const res = await resilientFetch(
    `${SITE}/wp-json/wp/v2/categories?per_page=100&orderby=count&order=desc&_fields=id,name,slug,count`
  );
  const data = (await res.json()) as WpCategory[];
  return data
    .filter((c) => c.count > 0 && c.slug !== "uncategorized")
    .map((c) => ({ ...c, name: decodeEntities(c.name) }));
}

/* ------------------------------------------------------------------ */
/* সম্পূর্ণ আর্টিকেল (পাবলিক WP REST)                                    */
/* ------------------------------------------------------------------ */

export async function fetchPostDetail(wpId: number): Promise<Partial<Post>> {
  try {
    const res = await resilientFetch(
      `${SITE}/wp-json/wp/v2/posts/${wpId}?_embed=wp:featuredmedia&_fields=content,title,link,_links,_embedded`
    );
    const d = (await res.json()) as {
      content?: { rendered?: string };
      _embedded?: { "wp:featuredmedia"?: { source_url?: string }[] };
    };
    if (d?.content?.rendered) {
      const plain = stripTags(d.content.rendered);
      return {
        html: sanitizeHtml(d.content.rendered),
        image: d._embedded?.["wp:featuredmedia"]?.[0]?.source_url ?? null,
        readMinutes: readingTime(plain),
      };
    }
  } catch {
    /* give up */
  }
  return {};
}

/** সাইটের সাথে সংযোগ যাচাই (সেটিংসে স্ট্যাটাস দেখানোর জন্য) — কোনো কী লাগে না */
export async function checkConnection(): Promise<{
  connected: boolean;
  name?: string;
  version?: string;
}> {
  try {
    const res = await resilientFetch(`${SITE}/wp-json/?_fields=name`, {}, 10000);
    const j = (await res.json()) as { name?: string };
    return { connected: true, name: j?.name };
  } catch {
    return { connected: false };
  }
}

/* ------------------------------------------------------------------ */
/* অফলাইন ক্যাশ (IndexedDB)                                             */
/* ------------------------------------------------------------------ */

export const saveCache = (key: string, posts: Post[]): Promise<void> =>
  setItem(`list:${key}`, {
    at: Date.now(),
    posts: posts.slice(0, 24).map(({ html: _h, ...p }) => p),
  });

export const readCache = async (key: string): Promise<Post[] | null> => {
  const hit = await getItem<{ at: number; posts: Post[] }>(`list:${key}`);
  if (!hit?.posts?.length) return null;
  return hit.posts.map((p) => ({ ...p, minutesAgo: minutesSince(p.dateISO) }));
};
