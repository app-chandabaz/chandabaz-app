/**
 * IndexedDB স্টোর (LocalForage-এর মতো সহজ getItem/setItem API)
 * ------------------------------------------------------------------
 * বড় টেক্সট (আর্টিকেলের পূর্ণ HTML, নিউজ তালিকা, ভিডিও মেটাডাটা) এখানে জমা
 * হয় — localStorage-এ নয়। IndexedDB না পেলে (যেমন প্রাইভেট মোড) সেশনের
 * জন্য মেমরি-ফলব্যাক ব্যবহার হয়, যাতে অ্যাপ কখনো ক্র্যাশ না করে।
 */
const DB_NAME = "chandabazbd-db";
const STORE = "kv";

let dbPromise: Promise<IDBDatabase | null> | null = null;
const mem = new Map<string, unknown>();

function openDb(): Promise<IDBDatabase | null> {
  if (dbPromise) return dbPromise;
  dbPromise = new Promise((resolve) => {
    try {
      if (typeof indexedDB === "undefined") return resolve(null);
      const req = indexedDB.open(DB_NAME, 1);
      req.onupgradeneeded = () => {
        if (!req.result.objectStoreNames.contains(STORE)) req.result.createObjectStore(STORE);
      };
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => resolve(null);
      req.onblocked = () => resolve(null);
    } catch {
      resolve(null);
    }
  });
  return dbPromise;
}

function run<T>(mode: IDBTransactionMode, fn: (s: IDBObjectStore) => IDBRequest<T>): Promise<T | null> {
  return openDb().then(
    (db) =>
      new Promise<T | null>((resolve) => {
        if (!db) return resolve(null);
        try {
          const tx = db.transaction(STORE, mode);
          const req = fn(tx.objectStore(STORE));
          req.onsuccess = () => resolve(req.result as T);
          req.onerror = () => resolve(null);
        } catch {
          resolve(null);
        }
      })
  );
}

export async function getItem<T>(key: string): Promise<T | null> {
  const db = await openDb();
  if (!db) return (mem.get(key) as T | undefined) ?? null;
  const v = await run<T>("readonly", (s) => s.get(key) as IDBRequest<T>);
  return v ?? null;
}

export async function setItem(key: string, value: unknown): Promise<void> {
  const db = await openDb();
  if (!db) {
    mem.set(key, value);
    return;
  }
  await run("readwrite", (s) => s.put(value, key));
}

export async function removeItem(key: string): Promise<void> {
  mem.delete(key);
  await run("readwrite", (s) => s.delete(key));
}

export async function listKeys(prefix = ""): Promise<string[]> {
  const db = await openDb();
  if (!db) return Array.from(mem.keys()).filter((k) => k.startsWith(prefix));
  const all = await run<IDBValidKey[]>("readonly", (s) => s.getAllKeys());
  return (all ?? []).map(String).filter((k) => k.startsWith(prefix));
}

/** নির্দিষ্ট প্রিফিক্সের সব এন্ট্রি মুছে ফেলা (ক্যাশ পরিষ্কারের জন্য) */
export async function clearPrefix(prefix: string): Promise<number> {
  const ks = await listKeys(prefix);
  await Promise.all(ks.map((k) => removeItem(k)));
  return ks.length;
}

/* ------------------------------------------------------------------ */
/* আর্টিকেল ক্যাশ (পূর্ণ HTML)                                          */
/* ------------------------------------------------------------------ */

export interface CachedArticle {
  html: string;
  image: string | null;
  readMinutes: number;
  at: number;
}

const ART = "article:";
const ART_INDEX = "article-index";
const MAX_ARTICLES = 100;

export async function getCachedArticle(id: string): Promise<CachedArticle | null> {
  return getItem<CachedArticle>(ART + id);
}

export async function cacheArticle(id: string, a: Omit<CachedArticle, "at">): Promise<void> {
  if (!a.html) return;
  await setItem(ART + id, { ...a, at: Date.now() });
  const index = ((await getItem<{ id: string; at: number }[]>(ART_INDEX)) ?? []).filter(
    (e) => e.id !== id
  );
  index.unshift({ id, at: Date.now() });
  // সীমা ছাড়ালে সবচেয়ে পুরনোগুলো মুছে ফেলা
  const drop = index.splice(MAX_ARTICLES);
  await Promise.all(drop.map((e) => removeItem(ART + e.id)));
  await setItem(ART_INDEX, index);
}

export async function articleCacheCount(): Promise<number> {
  return ((await getItem<unknown[]>(ART_INDEX)) ?? []).length;
}

export async function clearAllCaches(): Promise<void> {
  await Promise.all([
    clearPrefix("article:"),
    clearPrefix("article-index"),
    clearPrefix("list:"),
    clearPrefix("world:"),
    clearPrefix("yt:"),
  ]);
}
