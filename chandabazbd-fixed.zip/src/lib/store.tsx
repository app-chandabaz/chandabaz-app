import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from "react";
import { haptic } from "./utils";
import type { Post } from "./api";

const KEY = "chandabazbd:prefs:v2";

/** সংরক্ষণের জন্য হালকা সংস্করণ (html বাদ) */
const slim = (p: Post): Post => ({ ...p, html: undefined });

export interface Prefs {
  dark: boolean;
  fontStep: number;
  saved: Post[];
  history: Post[];
  recentSearches: string[];
  pushBreaking: boolean;
  pushSports: boolean;
  pushDaily: boolean;
  dataSaver: boolean;
  worldSources: string[];
}

const defaults: Prefs = {
  dark: true,
  fontStep: 1,
  saved: [],
  history: [],
  recentSearches: [],
  pushBreaking: true,
  pushSports: true,
  pushDaily: false,
  dataSaver: false,
  worldSources: ["bbcbangla", "prothomalo", "bbcworld", "aljazeera", "un"],
};

interface Toast {
  id: number;
  msg: string;
  icon?: string;
}

interface Ctx extends Prefs {
  set: <K extends keyof Prefs>(key: K, value: Prefs[K]) => void;
  toggleSave: (p: Post) => void;
  isSaved: (id: string) => boolean;
  pushHistory: (p: Post) => void;
  addSearch: (q: string) => void;
  clearSearches: () => void;
  toast: (msg: string, icon?: string) => void;
  toasts: Toast[];
  fontPx: number;
}

const AppCtx = createContext<Ctx | null>(null);

const load = (): Prefs => {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return defaults;
    return { ...defaults, ...(JSON.parse(raw) as Partial<Prefs>) };
  } catch {
    return defaults;
  }
};

export function AppProvider({ children }: { children: ReactNode }) {
  const [prefs, setPrefs] = useState<Prefs>(() =>
    typeof window === "undefined" ? defaults : load()
  );
  const [toasts, setToasts] = useState<Toast[]>([]);

  useEffect(() => {
    try {
      localStorage.setItem(KEY, JSON.stringify(prefs));
    } catch {
      /* quota exceeded */
    }
  }, [prefs]);

  const set = useCallback(<K extends keyof Prefs>(key: K, value: Prefs[K]) => {
    setPrefs((p) => ({ ...p, [key]: value }));
  }, []);

  const toast = useCallback((msg: string, icon?: string) => {
    const id = Date.now() + Math.random();
    setToasts((t) => [...t, { id, msg, icon }]);
    setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), 2300);
  }, []);

  const toggleSave = useCallback(
    (post: Post) => {
      haptic();
      const has = prefs.saved.some((s) => s.id === post.id);
      setPrefs((p) => ({
        ...p,
        saved: has
          ? p.saved.filter((s) => s.id !== post.id)
          : [slim(post), ...p.saved].slice(0, 80),
      }));
      toast(has ? "সংরক্ষণ থেকে সরানো হয়েছে" : "সংরক্ষিত তালিকায় যুক্ত হয়েছে", has ? "🗑️" : "🔖");
    },
    [prefs.saved, toast]
  );

  const isSaved = useCallback(
    (id: string) => prefs.saved.some((s) => s.id === id),
    [prefs.saved]
  );

  const pushHistory = useCallback((post: Post) => {
    setPrefs((p) => ({
      ...p,
      history: [slim(post), ...p.history.filter((h) => h.id !== post.id)].slice(0, 40),
    }));
  }, []);

  const addSearch = useCallback((q: string) => {
    const term = q.trim();
    if (!term) return;
    setPrefs((p) => ({
      ...p,
      recentSearches: [term, ...p.recentSearches.filter((s) => s !== term)].slice(0, 8),
    }));
  }, []);

  const clearSearches = useCallback(() => setPrefs((p) => ({ ...p, recentSearches: [] })), []);

  const value = useMemo<Ctx>(
    () => ({
      ...prefs,
      set,
      toggleSave,
      isSaved,
      pushHistory,
      addSearch,
      clearSearches,
      toast,
      toasts,
      fontPx: [15, 17, 19, 21, 24][prefs.fontStep] ?? 17,
    }),
    [prefs, set, toggleSave, isSaved, pushHistory, addSearch, clearSearches, toast, toasts]
  );

  return <AppCtx.Provider value={value}>{children}</AppCtx.Provider>;
}

export function useApp() {
  const ctx = useContext(AppCtx);
  if (!ctx) throw new Error("useApp must be used inside AppProvider");
  return ctx;
}
