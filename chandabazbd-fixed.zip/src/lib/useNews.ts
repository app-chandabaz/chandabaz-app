import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  fetchCategories,
  fetchPosts,
  readCache,
  saveCache,
  type Post,
  type WpCategory,
} from "./api";

export type LoadState = "idle" | "loading" | "ready" | "error";

/** সাইটের ক্যাটাগরি (একবার লোড হয়ে ক্যাশ হয়) */
export function useCategories() {
  const [cats, setCats] = useState<WpCategory[]>(() => {
    try {
      return JSON.parse(localStorage.getItem("chandabazbd:cats") ?? "[]");
    } catch {
      return [];
    }
  });

  useEffect(() => {
    let alive = true;
    fetchCategories()
      .then((c) => {
        if (!alive || !c.length) return;
        setCats(c);
        try {
          localStorage.setItem("chandabazbd:cats", JSON.stringify(c));
        } catch {
          /* quota */
        }
      })
      .catch(() => {});
    return () => {
      alive = false;
    };
  }, []);

  const map = useMemo(() => new Map(cats.map((c) => [c.id, c.name])), [cats]);
  return { cats, catMap: map };
}

interface FeedOpts {
  categoryId?: number;
  search?: string;
  perPage?: number;
  cacheKey?: string;
  enabled?: boolean;
}

/** পেজিনেশন সহ পোস্ট ফিড */
export function usePostFeed(catMap: Map<number, string>, opts: FeedOpts = {}) {
  const { categoryId, search, perPage = 14, cacheKey, enabled = true } = opts;
  const [posts, setPosts] = useState<Post[]>([]);
  const [state, setState] = useState<LoadState>("idle");
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [loadingMore, setLoadingMore] = useState(false);
  const [fromCache, setFromCache] = useState(false);
  const reqId = useRef(0);

  const load = useCallback(
    async (targetPage: number, mode: "replace" | "append") => {
      if (!enabled) return;
      const my = ++reqId.current;
      if (mode === "replace") {
        setState("loading");
        if (cacheKey) {
          const cached = readCache(cacheKey);
          if (cached?.length) {
            setPosts(cached);
            setFromCache(true);
          }
        }
      } else setLoadingMore(true);

      try {
        const { posts: fresh, totalPages: tp } = await fetchPosts(
          { page: targetPage, perPage, categoryId, search },
          catMap
        );
        if (my !== reqId.current) return;
        setTotalPages(tp);
        setFromCache(false);
        setPosts((prev) => {
          if (mode === "replace") return fresh;
          const seen = new Set(prev.map((p) => p.id));
          return [...prev, ...fresh.filter((p) => !seen.has(p.id))];
        });
        setPage(targetPage);
        setState("ready");
        if (mode === "replace" && cacheKey && fresh.length) saveCache(cacheKey, fresh);
      } catch {
        if (my !== reqId.current) return;
        setPosts((prev) => {
          setState(prev.length ? "ready" : "error");
          return prev;
        });
      } finally {
        if (my === reqId.current) setLoadingMore(false);
      }
    },
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [categoryId, search, perPage, cacheKey, enabled, catMap]
  );

  useEffect(() => {
    load(1, "replace");
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [categoryId, search, enabled, catMap]);

  const refresh = useCallback(() => load(1, "replace"), [load]);
  const loadMore = useCallback(() => {
    if (loadingMore || page >= totalPages) return;
    load(page + 1, "append");
  }, [load, loadingMore, page, totalPages]);

  return {
    posts,
    state,
    refresh,
    loadMore,
    loadingMore,
    hasMore: page < totalPages,
    fromCache,
  };
}
