const bnDigits = ["০", "১", "২", "৩", "৪", "৫", "৬", "৭", "৮", "৯"];

export const toBn = (value: number | string): string =>
  String(value).replace(/\d/g, (d) => bnDigits[Number(d)]);

export const formatViews = (n: number): string => {
  if (n >= 100000) return `${toBn((n / 100000).toFixed(1))} লাখ`;
  if (n >= 1000) return `${toBn((n / 1000).toFixed(1))} হাজার`;
  return toBn(n);
};

export const timeAgo = (minutes: number): string => {
  if (minutes < 1) return "এইমাত্র";
  if (minutes < 60) return `${toBn(Math.floor(minutes))} মিনিট আগে`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${toBn(hours)} ঘণ্টা আগে`;
  const days = Math.floor(hours / 24);
  if (days < 30) return `${toBn(days)} দিন আগে`;
  return `${toBn(Math.floor(days / 30))} মাস আগে`;
};

const bnDays = [
  "রবিবার",
  "সোমবার",
  "মঙ্গলবার",
  "বুধবার",
  "বৃহস্পতিবার",
  "শুক্রবার",
  "শনিবার",
];

const bnMonths = [
  "জানুয়ারি",
  "ফেব্রুয়ারি",
  "মার্চ",
  "এপ্রিল",
  "মে",
  "জুন",
  "জুলাই",
  "আগস্ট",
  "সেপ্টেম্বর",
  "অক্টোবর",
  "নভেম্বর",
  "ডিসেম্বর",
];

export const banglaDate = (d: Date = new Date()): string =>
  `${bnDays[d.getDay()]}, ${toBn(d.getDate())} ${bnMonths[d.getMonth()]} ${toBn(d.getFullYear())}`;

export const banglaShortDate = (d: Date = new Date()): string =>
  `${toBn(d.getDate())} ${bnMonths[d.getMonth()]} ${toBn(d.getFullYear())}`;

export const banglaClock = (d: Date = new Date()): string => {
  let h = d.getHours();
  const m = d.getMinutes();
  const suffix = h < 6 ? "রাত" : h < 12 ? "সকাল" : h < 16 ? "দুপুর" : h < 19 ? "বিকেল" : "রাত";
  h = h % 12 || 12;
  return `${suffix} ${toBn(h)}:${toBn(String(m).padStart(2, "0"))}`;
};

export const clockHHMM = (d: Date = new Date()): string =>
  `${toBn(String(d.getHours() % 12 || 12))}:${toBn(String(d.getMinutes()).padStart(2, "0"))}`;

export const haptic = (ms = 12) => {
  if (typeof navigator !== "undefined" && "vibrate" in navigator) {
    try {
      navigator.vibrate(ms);
    } catch {
      /* noop */
    }
  }
};
