/**
 * আন্তর্জাতিক সংবাদ অ্যাগ্রিগেটর
 * ------------------------------------------------------------------
 * একাধিক আন্তর্জাতিক সংবাদ সংস্থার RSS ফিড টেনে এনে একই Post কাঠামোয়
 * রূপান্তর করে। RSS ফিডে CORS না থাকায় পাবলিক প্রক্সি ব্যবহার হয় —
 * তাই একাধিক প্রক্সি failover + লোকাল ক্যাশ রাখা হয়েছে, যাতে কোনো
 * প্রক্সি ব্যর্থ হলেও ব্যবহারকারী সর্বশেষ সংবাদ দেখতে পান।
 */
import { decodeEntities, minutesSince, sanitizeHtml, stripTags, type Post } from "./api";
import { getItem, setItem } from "./db";

export interface Source {
  id: string;
  name: string;
  short: string;
  url: string;
  lang: "bn" | "en";
  group: "intl" | "bd";
  color: string;
}

export const SOURCES: Source[] = [
  /* 🌍 আন্তর্জাতিক */
  { id: "bbcworld", name: "BBC World", short: "BBC", url: "https://feeds.bbci.co.uk/news/world/rss.xml", lang: "en", group: "intl", color: "#8c1a1a" },
  { id: "bbcbangla", name: "বিবিসি বাংলা", short: "BBC", url: "https://feeds.bbci.co.uk/bengali/rss.xml", lang: "bn", group: "intl", color: "#bb1919" },
  { id: "aljazeera", name: "Al Jazeera", short: "AJ", url: "https://www.aljazeera.com/xml/rss/all.xml", lang: "en", group: "intl", color: "#fa9000" },
  { id: "un", name: "UN News", short: "UN", url: "https://news.un.org/feed/subscribe/en/news/all/rss.xml", lang: "en", group: "intl", color: "#009edb" },
  /* 🇧🇩 বাংলাদেশি */
  { id: "prothomalo", name: "প্রথম আলো", short: "PA", url: "https://www.prothomalo.com/feed/", lang: "bn", group: "bd", color: "#e4002b" },
  { id: "kalerkantho", name: "কালের কণ্ঠ", short: "KK", url: "https://www.kalerkantho.com/rss.xml", lang: "bn", group: "bd", color: "#0b6e4f" },
  { id: "jamunatv", name: "যমুনা টিভি", short: "JTV", url: "https://jamuna.tv/feed", lang: "bn", group: "bd", color: "#1d4ed8" },
  { id: "dhakapost", name: "ঢাকা পোস্ট", short: "DP", url: "https://www.dhakapost.com/rss.xml", lang: "bn", group: "bd", color: "#c2410c" },
  { id: "amardesh", name: "আমার দেশ", short: "AD", url: "https://www.dailyamardesh.com/feed", lang: "bn", group: "bd", color: "#15803d" },
  { id: "banglanews24", name: "বাংলা নিউজ ২৪", short: "BN", url: "https://www.banglanews24.com/rss/rss.xml", lang: "bn", group: "bd", color: "#7c3aed" },
  { id: "jagonews24", name: "জাগোনিউজ২৪", short: "JN", url: "https://www.jagonews24.com/rss/rss.xml", lang: "bn", group: "bd", color: "#be185d" },
  { id: "jugantor", name: "যুগান্তর", short: "JG", url: "https://www.jugantor.com/feed/rss.xml", lang: "bn", group: "bd", color: "#0369a1" },
  { id: "dailystar", name: "দ্য ডেইলি স্টার", short: "DS", url: "https://www.thedailystar.net/frontpage/rss.xml", lang: "en", group: "bd", color: "#b91c1c" },
];

export const sourceById = (id: string) => SOURCES.find((s) => s.id === id);

/* ------------------------------------------------------------------ */
/* প্রক্সি                                                              */
/* ------------------------------------------------------------------ */

type Proxy = { make: (u: string) => string; json?: boolean };

const PROXIES: Proxy[] = [
  { make: (u) => `https://api.allorigins.win/raw?url=${encodeURIComponent(u)}` },
  { make: (u) => `https://api.allorigins.win/get?url=${encodeURIComponent(u)}`, json: true },
  { make: (u) => `https://api.codetabs.com/v1/proxy?quest=${encodeURIComponent(u)}` },
  { make: (u) => `https://corsproxy.io/?url=${encodeURIComponent(u)}` },
  { make: (u) => `https://cors.eu.org/${u}` },
];

const timeout = (ms: number) => {
  const c = new AbortController();
  setTimeout(() => c.abort(), ms);
  return c.signal;
};

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

/** প্রক্সি ঘুরিয়ে ঘুরিয়ে যেকোনো টেক্সট (XML/HTML) আনার চেষ্টা */
export async function fetchViaProxies(
  url: string,
  accept: (text: string) => boolean,
  startAt = 0
): Promise<string | null> {
  for (let i = 0; i < PROXIES.length; i++) {
    const p = PROXIES[(startAt + i) % PROXIES.length];
    try {
      const res = await fetch(p.make(url), { signal: timeout(12000) });
      if (!res.ok) continue;
      let text = await res.text();
      if (p.json || (text.startsWith("{") && text.includes('"contents"'))) {
        try {
          text = JSON.parse(text).contents ?? text;
        } catch {
          /* raw */
        }
      }
      if (accept(text)) return text;
    } catch {
      /* পরের প্রক্সি */
    }
  }
  return null;
}

const fetchXml = (url: string, startAt = 0) =>
  fetchViaProxies(url, (t) => t.includes("<item") || t.includes("<entry"), startAt);

/* ------------------------------------------------------------------ */
/* ক্যাশ                                                                */
/* ------------------------------------------------------------------ */

const cacheGet = async (id: string): Promise<Post[] | null> => {
  const hit = await getItem<{ at: number; posts: Post[] }>(`world:${id}`);
  if (!hit?.posts?.length) return null;
  return hit.posts.map((p) => ({ ...p, minutesAgo: minutesSince(p.dateISO) }));
};

const cacheSet = (id: string, posts: Post[]) =>
  setItem(`world:${id}`, { at: Date.now(), posts: posts.slice(0, 15) });

/* ------------------------------------------------------------------ */
/* পার্সিং                                                              */
/* ------------------------------------------------------------------ */

const attrUrl = (el: Element | null) =>
  el?.getAttribute("url") ?? el?.getAttribute("href") ?? null;

function extractImage(item: Element, rawHtml: string): string | null {
  const byTag = (t: string) => item.getElementsByTagName(t)[0] ?? null;
  const found = [
    attrUrl(byTag("media:thumbnail")),
    attrUrl(byTag("media:content")),
    attrUrl(byTag("enclosure")),
  ].filter(Boolean) as string[];
  if (found.length) return found[0];
  const m = rawHtml.match(/<img[^>]+src=["']([^"']+)["']/i);
  return m ? m[1] : null;
}

/** BBC-এর ছোট থাম্বনেইলকে বড় সংস্করণে রূপান্তর */
const upscale = (u: string | null) =>
  u
    ? u.replace(/\/ace\/ws\/\d+\//, "/ace/ws/640/").replace(/\/(\d{2,3})x(\d{2,3})\//, "/800x450/")
    : u;

const hashStr = (str: string) => {
  let h = 5381;
  for (let i = 0; i < str.length; i++) h = ((h << 5) + h + str.charCodeAt(i)) | 0;
  return (h >>> 0).toString(36);
};

function parseFeed(xml: string, src: Source): Post[] {
  let doc: Document;
  try {
    doc = new DOMParser().parseFromString(xml, "text/xml");
  } catch {
    return [];
  }
  if (doc.querySelector("parsererror")) {
    try {
      doc = new DOMParser().parseFromString(xml, "text/html");
    } catch {
      return [];
    }
  }

  const nodes = Array.from(doc.querySelectorAll("item"));
  const entries = nodes.length ? nodes : Array.from(doc.querySelectorAll("entry"));

  return entries
    .slice(0, 15)
    .map((it) => {
      const txt = (t: string) => it.querySelector(t)?.textContent?.trim() ?? "";
      const rawDesc =
        it.getElementsByTagName("content:encoded")[0]?.textContent ??
        txt("description") ??
        txt("summary") ??
        txt("content") ??
        "";
      const title = decodeEntities(txt("title")).trim();
      if (!title) return null;
      const link =
        txt("link") || it.querySelector("link")?.getAttribute("href") || src.url;
      const dateRaw =
        txt("pubDate") ||
        it.getElementsByTagName("dc:date")[0]?.textContent ||
        txt("updated") ||
        txt("published") ||
        "";
      const parsed = dateRaw ? new Date(dateRaw) : new Date();
      const iso = Number.isNaN(parsed.getTime()) ? new Date().toISOString() : parsed.toISOString();
      const plain = stripTags(rawDesc);

      return {
        id: `${src.id}-${hashStr(link || title)}`,
        title,
        excerpt: plain.slice(0, 200),
        html: sanitizeHtml(rawDesc),
        image: upscale(extractImage(it, rawDesc)),
        dateISO: iso,
        minutesAgo: minutesSince(iso),
        link,
        catIds: [],
        catNames: [src.group === "bd" ? "বাংলাদেশ" : src.lang === "bn" ? "আন্তর্জাতিক" : "International"],
        source: src.name,
        sourceId: src.id,
        external: true,
        readMinutes: Math.max(1, Math.round(plain.length / 700)),
      } satisfies Post;
    })
    .filter(Boolean) as Post[];
}

/* ------------------------------------------------------------------ */
/* পাবলিক API                                                           */
/* ------------------------------------------------------------------ */

export interface SourceResult {
  source: Source;
  posts: Post[];
  cached: boolean;
  ok: boolean;
}

/** একটি উৎস — ব্যর্থ হলে ক্যাশ থেকে */
export async function fetchSource(src: Source, proxyOffset = 0): Promise<SourceResult> {
  const xml = await fetchXml(src.url, proxyOffset);
  if (xml) {
    const posts = parseFeed(xml, src);
    if (posts.length) {
      cacheSet(src.id, posts);
      return { source: src, posts, cached: false, ok: true };
    }
  }
  const cached = await cacheGet(src.id);
  return { source: src, posts: cached ?? [], cached: !!cached, ok: false };
}

export interface WorldResult {
  posts: Post[];
  failed: string[];
  usingCache: boolean;
  results: SourceResult[];
}

/**
 * সব সক্রিয় উৎস — একসাথে নয়, ২টি করে ব্যাচে (প্রক্সি রেট-লিমিট এড়াতে)
 * এবং প্রতিটি উৎসের জন্য আলাদা প্রক্সি দিয়ে শুরু (লোড ছড়িয়ে দিতে)।
 */
export async function fetchWorldNews(sourceIds?: string[]): Promise<WorldResult> {
  const list = sourceIds?.length ? SOURCES.filter((s) => sourceIds.includes(s.id)) : SOURCES;

  const results: SourceResult[] = [];
  const BATCH = 3;
  for (let i = 0; i < list.length; i += BATCH) {
    const batch = list.slice(i, i + BATCH);
    const done = await Promise.all(batch.map((s, j) => fetchSource(s, i + j)));
    results.push(...done);
    if (i + BATCH < list.length) await sleep(250);
  }

  const posts = results.flatMap((r) => r.posts);
  posts.sort((a, b) => a.minutesAgo - b.minutesAgo);

  return {
    posts,
    failed: results.filter((r) => !r.ok && !r.posts.length).map((r) => r.source.id),
    usingCache: results.some((r) => r.cached),
    results,
  };
}

/** তাৎক্ষণিক প্রদর্শনের জন্য ক্যাশ (IndexedDB) থেকে — নেটওয়ার্ক ছাড়াই */
export async function cachedWorldNews(sourceIds?: string[]): Promise<Post[]> {
  const list = sourceIds?.length ? SOURCES.filter((s) => sourceIds.includes(s.id)) : SOURCES;
  const all = await Promise.all(list.map((s) => cacheGet(s.id)));
  const posts = all.flatMap((p) => p ?? []);
  posts.sort((a, b) => a.minutesAgo - b.minutesAgo);
  return posts;
}
