/**
 * আন্তর্জাতিক সংবাদ অ্যাগ্রিগেটর
 * ------------------------------------------------------------------
 * একাধিক আন্তর্জাতিক সংবাদ সংস্থার RSS ফিড টেনে এনে একই Post কাঠামোয়
 * রূপান্তর করে। RSS ফিডে CORS না থাকায় পাবলিক প্রক্সি ব্যবহার হয় —
 * তাই একাধিক প্রক্সি failover + লোকাল ক্যাশ রাখা হয়েছে, যাতে কোনো
 * প্রক্সি ব্যর্থ হলেও ব্যবহারকারী সর্বশেষ সংবাদ দেখতে পান।
 */
import { decodeEntities, minutesSince, sanitizeHtml, stripTags, type Post } from "./api";

export interface Source {
  id: string;
  name: string;
  short: string;
  url: string;
  lang: "bn" | "en";
  color: string;
}

export const SOURCES: Source[] = [
  {
    id: "bbcbangla",
    name: "বিবিসি বাংলা",
    short: "BBC",
    url: "https://feeds.bbci.co.uk/bengali/rss.xml",
    lang: "bn",
    color: "#bb1919",
  },
  {
    id: "prothomalo",
    name: "প্রথম আলো",
    short: "PA",
    url: "https://www.prothomalo.com/feed",
    lang: "bn",
    color: "#e4002b",
  },
  {
    id: "bbcworld",
    name: "BBC World",
    short: "BBC",
    url: "https://feeds.bbci.co.uk/news/world/rss.xml",
    lang: "en",
    color: "#8c1a1a",
  },
  {
    id: "aljazeera",
    name: "Al Jazeera",
    short: "AJ",
    url: "https://www.aljazeera.com/xml/rss/all.xml",
    lang: "en",
    color: "#fa9000",
  },
  {
    id: "un",
    name: "UN News",
    short: "UN",
    url: "https://news.un.org/feed/subscribe/en/news/all/rss.xml",
    lang: "en",
    color: "#009edb",
  },
];

export const sourceById = (id: string) => SOURCES.find((s) => s.id === id);

/* ------------------------------------------------------------------ */
/* প্রক্সি                                                              */
/* ------------------------------------------------------------------ */

type Proxy = { make: (u: string) => string; json?: boolean };

const PROXIES: Proxy[] = [
  { make: (u) => `https://api.allorigins.win/raw?url=${encodeURIComponent(u)}` },
  { make: (u) => `https://api.allorigins.win/get?url=${encodeURIComponent(u)}`, json: true },
  { make: (u) => `https://api.codetabs.com/v1/proxy?quest=${encodeURIComponent(u)}` },
  { make: (u) => `https://corsproxy.io/?url=${encodeURIComponent(u)}` },
  { make: (u) => `https://cors.eu.org/${u}` },
];

const timeout = (ms: number) => {
  const c = new AbortController();
  setTimeout(() => c.abort(), ms);
  return c.signal;
};

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

/** প্রক্সি ঘুরিয়ে ঘুরিয়ে XML আনার চেষ্টা */
async function fetchXml(url: string, startAt = 0): Promise<string | null> {
  for (let i = 0; i < PROXIES.length; i++) {
    const p = PROXIES[(startAt + i) % PROXIES.length];
    try {
      const res = await fetch(p.make(url), { signal: timeout(12000) });
      if (!res.ok) continue;
      let text = await res.text();
      if (p.json || (text.startsWith("{") && text.includes('"contents"'))) {
        try {
          text = JSON.parse(text).contents ?? text;
        } catch {
          /* raw */
        }
      }
      if (text.includes("<item") || text.includes("<entry")) return text;
    } catch {
      /* পরের প্রক্সি */
    }
  }
  return null;
}

/* ------------------------------------------------------------------ */
/* ক্যাশ                                                                */
/* ------------------------------------------------------------------ */

const CACHE = "chandabazbd:world:v1";

type CacheShape = Record<string, { at: number; posts: Post[] }>;

const readStore = (): CacheShape => {
  try {
    return JSON.parse(localStorage.getItem(CACHE) ?? "{}");
  } catch {
    return {};
  }
};

const cacheGet = (id: string): Post[] | null => {
  const hit = readStore()[id];
  if (!hit?.posts?.length) return null;
  return hit.posts.map((p) => ({ ...p, minutesAgo: minutesSince(p.dateISO) }));
};

const cacheSet = (id: string, posts: Post[]) => {
  try {
    const all = readStore();
    all[id] = { at: Date.now(), posts: posts.slice(0, 15) };
    localStorage.setItem(CACHE, JSON.stringify(all));
  } catch {
    /* quota */
  }
};

export const cacheAge = (id: string): number | null => {
  const hit = readStore()[id];
  return hit ? Math.round((Date.now() - hit.at) / 60000) : null;
};

/* ------------------------------------------------------------------ */
/* পার্সিং                                                              */
/* ------------------------------------------------------------------ */

const attrUrl = (el: Element | null) =>
  el?.getAttribute("url") ?? el?.getAttribute("href") ?? null;

function extractImage(item: Element, rawHtml: string): string | null {
  const byTag = (t: string) => item.getElementsByTagName(t)[0] ?? null;
  const found = [
    attrUrl(byTag("media:thumbnail")),
    attrUrl(byTag("media:content")),
    attrUrl(byTag("enclosure")),
  ].filter(Boolean) as string[];
  if (found.length) return found[0];
  const m = rawHtml.match(/<img[^>]+src=["']([^"']+)["']/i);
  return m ? m[1] : null;
}

/** BBC-এর ছোট থাম্বনেইলকে বড় সংস্করণে রূপান্তর */
const upscale = (u: string | null) =>
  u
    ? u.replace(/\/ace\/ws\/\d+\//, "/ace/ws/640/").replace(/\/(\d{2,3})x(\d{2,3})\//, "/800x450/")
    : u;

function parseFeed(xml: string, src: Source): Post[] {
  let doc: Document;
  try {
    doc = new DOMParser().parseFromString(xml, "text/xml");
  } catch {
    return [];
  }
  if (doc.querySelector("parsererror")) {
    try {
      doc = new DOMParser().parseFromString(xml, "text/html");
    } catch {
      return [];
    }
  }

  const nodes = Array.from(doc.querySelectorAll("item"));
  const entries = nodes.length ? nodes : Array.from(doc.querySelectorAll("entry"));

  return entries
    .slice(0, 15)
    .map((it, i) => {
      const txt = (t: string) => it.querySelector(t)?.textContent?.trim() ?? "";
      const rawDesc =
        it.getElementsByTagName("content:encoded")[0]?.textContent ??
        txt("description") ??
        txt("summary") ??
        txt("content") ??
        "";
      const title = decodeEntities(txt("title")).trim();
      if (!title) return null;
      const link =
        txt("link") || it.querySelector("link")?.getAttribute("href") || src.url;
      const dateRaw =
        txt("pubDate") ||
        it.getElementsByTagName("dc:date")[0]?.textContent ||
        txt("updated") ||
        txt("published") ||
        "";
      const parsed = dateRaw ? new Date(dateRaw) : new Date();
      const iso = Number.isNaN(parsed.getTime()) ? new Date().toISOString() : parsed.toISOString();
      const plain = stripTags(rawDesc);

      return {
        id: `${src.id}-${i}-${iso}`,
        title,
        excerpt: plain.slice(0, 200),
        html: sanitizeHtml(rawDesc),
        image: upscale(extractImage(it, rawDesc)),
        dateISO: iso,
        minutesAgo: minutesSince(iso),
        link,
        catIds: [],
        catNames: [src.lang === "bn" ? "আন্তর্জাতিক" : "International"],
        source: src.name,
        sourceId: src.id,
        external: true,
        readMinutes: Math.max(1, Math.round(plain.length / 700)),
      } satisfies Post;
    })
    .filter(Boolean) as Post[];
}

/* ------------------------------------------------------------------ */
/* পাবলিক API                                                           */
/* ------------------------------------------------------------------ */

export interface SourceResult {
  source: Source;
  posts: Post[];
  cached: boolean;
  ok: boolean;
}

/** একটি উৎস — ব্যর্থ হলে ক্যাশ থেকে */
export async function fetchSource(src: Source, proxyOffset = 0): Promise<SourceResult> {
  const xml = await fetchXml(src.url, proxyOffset);
  if (xml) {
    const posts = parseFeed(xml, src);
    if (posts.length) {
      cacheSet(src.id, posts);
      return { source: src, posts, cached: false, ok: true };
    }
  }
  const cached = cacheGet(src.id);
  return { source: src, posts: cached ?? [], cached: !!cached, ok: false };
}

export interface WorldResult {
  posts: Post[];
  failed: string[];
  usingCache: boolean;
  results: SourceResult[];
}

/**
 * সব সক্রিয় উৎস — একসাথে নয়, ২টি করে ব্যাচে (প্রক্সি রেট-লিমিট এড়াতে)
 * এবং প্রতিটি উৎসের জন্য আলাদা প্রক্সি দিয়ে শুরু (লোড ছড়িয়ে দিতে)।
 */
export async function fetchWorldNews(sourceIds?: string[]): Promise<WorldResult> {
  const list = sourceIds?.length ? SOURCES.filter((s) => sourceIds.includes(s.id)) : SOURCES;

  const results: SourceResult[] = [];
  const BATCH = 2;
  for (let i = 0; i < list.length; i += BATCH) {
    const batch = list.slice(i, i + BATCH);
    const done = await Promise.all(batch.map((s, j) => fetchSource(s, i + j)));
    results.push(...done);
    if (i + BATCH < list.length) await sleep(350);
  }

  const posts = results.flatMap((r) => r.posts);
  posts.sort((a, b) => a.minutesAgo - b.minutesAgo);

  return {
    posts,
    failed: results.filter((r) => !r.ok && !r.posts.length).map((r) => r.source.id),
    usingCache: results.some((r) => r.cached),
    results,
  };
}

/** তাৎক্ষণিক প্রদর্শনের জন্য ক্যাশ থেকে (নেটওয়ার্ক ছাড়াই) */
export function cachedWorldNews(sourceIds?: string[]): Post[] {
  const list = sourceIds?.length ? SOURCES.filter((s) => sourceIds.includes(s.id)) : SOURCES;
  const posts = list.flatMap((s) => cacheGet(s.id) ?? []);
  posts.sort((a, b) => a.minutesAgo - b.minutesAgo);
  return posts;
}
