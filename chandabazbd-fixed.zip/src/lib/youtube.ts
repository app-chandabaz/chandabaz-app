/**
 * YouTube ভিডিও উৎস
 * ------------------------------------------------------------------
 * API কী ছাড়াই প্রতিটি চ্যানেলের পাবলিক RSS ফিড
 * (youtube.com/feeds/videos.xml?channel_id=…) থেকে সর্বশেষ ভিডিও আনা হয়।
 * @handle থেকে চ্যানেল আইডি প্রথমবার বের করে IndexedDB-তে সংরক্ষণ করা হয়।
 */
import { minutesSince } from "./api";
import { getItem, setItem } from "./db";
import { fetchViaProxies } from "./world";

export interface Channel {
  id: string;
  name: string;
  handle: string;
  short: string;
  color: string;
  /** জানা থাকলে সরাসরি; না থাকলে handle থেকে খুঁজে নেওয়া হয় */
  channelId?: string;
}

export const CHANNELS: Channel[] = [
  { id: "bbcbangla", name: "বিবিসি নিউজ বাংলা", handle: "BBCNewsBangla", short: "BBC", color: "#bb1919" },
  { id: "aljazeera", name: "Al Jazeera English", handle: "aljazeeraenglish", short: "AJ", color: "#fa9000", channelId: "UCNye-wNBqNL5ZzHSJj3l8Bg" },
  { id: "jamunatv", name: "যমুনা টিভি", handle: "JamunaTVbd", short: "JTV", color: "#1d4ed8" },
  { id: "prothomalo", name: "প্রথম আলো", handle: "ProthomAlo", short: "PA", color: "#e4002b" },
  { id: "kalerkantho", name: "কালের কণ্ঠ", handle: "KalerKantho", short: "KK", color: "#0b6e4f" },
  { id: "dhakapost", name: "ঢাকা পোস্ট", handle: "DhakaPost", short: "DP", color: "#c2410c" },
  { id: "amardesh", name: "দৈনিক আমার দেশ", handle: "DailyAmarDesh", short: "AD", color: "#15803d" },
  { id: "banglanews24", name: "বাংলা নিউজ ২৪", handle: "Banglanews24", short: "BN", color: "#7c3aed" },
  { id: "jagonews24", name: "জাগোনিউজ২৪", handle: "JagoNews24", short: "JN", color: "#be185d" },
  { id: "jugantor", name: "যুগান্তর", handle: "DailyJugantorbd", short: "JG", color: "#0369a1" },
  { id: "dailystar", name: "দ্য ডেইলি স্টার", handle: "TheDailyStarNews", short: "DS", color: "#b91c1c" },
];

export const channelById = (id: string) => CHANNELS.find((c) => c.id === id);

export interface Video {
  id: string; // YouTube videoId
  title: string;
  channelKey: string;
  channelName: string;
  publishedISO: string;
  minutesAgo: number;
  thumb: string;
}

export const thumbUrl = (videoId: string) => `https://i.ytimg.com/vi/${videoId}/hqdefault.jpg`;

/* ------------------------------------------------------------------ */

async function resolveChannelId(ch: Channel): Promise<string | null> {
  if (ch.channelId) return ch.channelId;
  const key = `yt:cid:${ch.handle}`;
  const saved = await getItem<string>(key);
  if (saved) return saved;

  const html = await fetchViaProxies(
    `https://www.youtube.com/@${ch.handle}`,
    (t) => /UC[\w-]{22}/.test(t)
  );
  if (!html) return null;
  const m =
    html.match(/rel="canonical" href="https:\/\/www\.youtube\.com\/channel\/(UC[\w-]{22})"/) ??
    html.match(/"externalId":"(UC[\w-]{22})"/) ??
    html.match(/"channelId":"(UC[\w-]{22})"/) ??
    html.match(/channel_id=(UC[\w-]{22})/);
  if (!m) return null;
  await setItem(key, m[1]);
  return m[1];
}

function parseVideos(xml: string, ch: Channel): Video[] {
  let doc: Document;
  try {
    doc = new DOMParser().parseFromString(xml, "text/xml");
  } catch {
    return [];
  }
  return Array.from(doc.querySelectorAll("entry"))
    .slice(0, 12)
    .map((e) => {
      const id = e.getElementsByTagName("yt:videoId")[0]?.textContent?.trim();
      const title = e.querySelector("title")?.textContent?.trim();
      if (!id || !title) return null;
      const pub = e.querySelector("published")?.textContent ?? "";
      const d = new Date(pub);
      const iso = Number.isNaN(d.getTime()) ? new Date().toISOString() : d.toISOString();
      return {
        id,
        title,
        channelKey: ch.id,
        channelName: ch.name,
        publishedISO: iso,
        minutesAgo: minutesSince(iso),
        thumb: thumbUrl(id),
      } satisfies Video;
    })
    .filter(Boolean) as Video[];
}

const withFreshAge = (v: Video): Video => ({ ...v, minutesAgo: minutesSince(v.publishedISO) });

async function cachedChannel(ch: Channel): Promise<Video[] | null> {
  const hit = await getItem<{ at: number; videos: Video[] }>(`yt:videos:${ch.id}`);
  return hit?.videos?.length ? hit.videos.map(withFreshAge) : null;
}

export interface ChannelResult {
  channel: Channel;
  videos: Video[];
  ok: boolean;
  cached: boolean;
}

export async function fetchChannel(ch: Channel, offset = 0): Promise<ChannelResult> {
  try {
    const cid = await resolveChannelId(ch);
    if (cid) {
      const xml = await fetchViaProxies(
        `https://www.youtube.com/feeds/videos.xml?channel_id=${cid}`,
        (t) => t.includes("<entry"),
        offset
      );
      if (xml) {
        const videos = parseVideos(xml, ch);
        if (videos.length) {
          await setItem(`yt:videos:${ch.id}`, { at: Date.now(), videos });
          return { channel: ch, videos, ok: true, cached: false };
        }
      }
    }
  } catch {
    /* ক্যাশে ফিরে যাই */
  }
  const cached = await cachedChannel(ch);
  return { channel: ch, videos: cached ?? [], ok: false, cached: !!cached };
}

export interface VideosResult {
  videos: Video[];
  failed: string[];
  usingCache: boolean;
}

/** একসাথে ৩টি চ্যানেল; প্রতিটি শেষ হলেই তালিকা আপডেট */
export async function fetchAllVideos(onPartial?: (v: Video[]) => void): Promise<VideosResult> {
  const results: ChannelResult[] = [];
  let next = 0;
  const merged = () =>
    results.flatMap((r) => r.videos).sort((a, b) => a.minutesAgo - b.minutesAgo);

  const worker = async () => {
    while (next < CHANNELS.length) {
      const i = next++;
      const r = await fetchChannel(CHANNELS[i], i);
      results.push(r);
      if (onPartial && r.videos.length) onPartial(merged());
    }
  };
  await Promise.all(Array.from({ length: 3 }, worker));

  return {
    videos: merged(),
    failed: results.filter((r) => !r.ok && !r.videos.length).map((r) => r.channel.id),
    usingCache: results.some((r) => r.cached),
  };
}

export async function cachedVideos(): Promise<Video[]> {
  const all = await Promise.all(CHANNELS.map((c) => cachedChannel(c)));
  return all.flatMap((v) => v ?? []).sort((a, b) => a.minutesAgo - b.minutesAgo);
}
