import { useEffect, useRef, useState } from "react";
import { fetchPostDetail, type Post } from "@/lib/api";
import { Icon } from "@/components/Icons";
import { Sheet } from "@/components/ui";
import NewsCard, { Thumb } from "@/components/NewsCard";
import { useApp } from "@/lib/store";
import { banglaShortDate, clockHHMM, haptic, timeAgo, toBn } from "@/lib/utils";
import { catStyle } from "@/data/catMeta";
import { sourceById } from "@/lib/world";
import { cacheArticle, getCachedArticle } from "@/lib/db";

export default function ArticleScreen({
  post,
  related,
  onBack,
  onOpen,
}: {
  post: Post;
  related: Post[];
  onBack: () => void;
  onOpen: (p: Post) => void;
}) {
  const { fontPx, fontStep, set, isSaved, toggleSave, toast, dark } = useApp();
  const [progress, setProgress] = useState(0);
  const [fontSheet, setFontSheet] = useState(false);
  const [shareSheet, setShareSheet] = useState(false);
  const [reaction, setReaction] = useState<string | null>(null);
  const [detail, setDetail] = useState<Partial<Post> | null>(null);
  const [loadingBody, setLoadingBody] = useState(false);
  const scroller = useRef<HTMLDivElement>(null);
  const saved = isSaved(post.id);
  const cat = post.catNames[0] ?? post.source;
  const style = catStyle(cat);
  const src = sourceById(post.sourceId);

  /* সম্পূর্ণ কনটেন্ট: ১) IndexedDB ক্যাশ → ২) WordPress API → ৩) ক্যাশে সংরক্ষণ */
  useEffect(() => {
    scroller.current?.scrollTo({ top: 0 });
    setDetail(null);
    setReaction(null);
    setLoadingBody(false);
    let alive = true;
    const SIX_HOURS = 6 * 60 * 60 * 1000;

    (async () => {
      const hit = await getCachedArticle(post.id);
      if (!alive) return;
      if (hit) setDetail({ html: hit.html, image: hit.image, readMinutes: hit.readMinutes });

      // বাইরের উৎসের (RSS) লেখা ইতোমধ্যে পোস্টেই আছে — শুধু ক্যাশে রাখা
      if (post.external || !post.wpId) {
        if (!hit && post.html)
          cacheArticle(post.id, {
            html: post.html,
            image: post.image,
            readMinutes: post.readMinutes,
          });
        return;
      }
      // তাজা ক্যাশ থাকলে নেটওয়ার্ক লাগবে না
      if (hit && Date.now() - hit.at < SIX_HOURS) return;

      if (!hit) setLoadingBody(true);
      try {
        const d = await fetchPostDetail(post.wpId);
        if (!alive) return;
        if (d.html) {
          setDetail(d);
          cacheArticle(post.id, {
            html: d.html,
            image: d.image ?? post.image,
            readMinutes: d.readMinutes ?? post.readMinutes,
          });
        }
      } catch {
        /* পুরনো ক্যাশই থাকুক */
      } finally {
        if (alive) setLoadingBody(false);
      }
    })();

    return () => {
      alive = false;
    };
  }, [post.id, post.wpId, post.external]);

  const onScroll = () => {
    const el = scroller.current;
    if (!el) return;
    const max = el.scrollHeight - el.clientHeight;
    setProgress(max > 0 ? Math.min(100, (el.scrollTop / max) * 100) : 0);
  };

  const share = async (target: string) => {
    haptic();
    const url = post.link;
    const enc = encodeURIComponent(url);
    const txt = encodeURIComponent(post.title);
    const web: Record<string, string> = {
      ফেসবুক: `https://www.facebook.com/sharer/sharer.php?u=${enc}`,
      হোয়াটসঅ্যাপ: `https://wa.me/?text=${txt}%20${enc}`,
      এক্স: `https://twitter.com/intent/tweet?text=${txt}&url=${enc}`,
      টেলিগ্রাম: `https://t.me/share/url?url=${enc}&text=${txt}`,
      ইমেইল: `mailto:?subject=${txt}&body=${enc}`,
    };
    if (target === "copy") {
      try {
        await navigator.clipboard.writeText(url);
        toast("লিংক কপি হয়েছে", "📋");
      } catch {
        toast("কপি করা যায়নি", "⚠️");
      }
    } else if (target === "native") {
      if (navigator.share) {
        try {
          await navigator.share({ title: post.title, url });
        } catch {
          /* cancelled */
        }
      } else toast("শেয়ার সাপোর্ট নেই", "⚠️");
    } else if (web[target]) {
      window.open(web[target], "_blank", "noopener");
    }
    setShareSheet(false);
  };

  const bodyHtml = detail?.html ?? post.html ?? null;
  const image = detail?.image ?? post.image;
  const readMins = detail?.readMinutes ?? post.readMinutes;

  return (
    <div className="animate-screen-in flex h-full flex-col bg-white dark:bg-ink-900">
      {/* header */}
      <div className="relative z-20 flex items-center gap-1 border-b border-zinc-200 bg-white/95 px-2 py-2 backdrop-blur dark:border-ink-700 dark:bg-ink-800/95">
        <button
          onClick={onBack}
          className="grid h-9 w-9 place-items-center rounded-full text-zinc-700 active:bg-zinc-100 dark:text-zinc-200 dark:active:bg-ink-700"
        >
          <Icon name="back" size={20} />
        </button>
        <span className="flex-1 truncate text-[13px] font-bold" style={{ color: style.color }}>
          {style.icon} {cat}
        </span>
        <button
          onClick={() => setFontSheet(true)}
          className="grid h-9 w-9 place-items-center rounded-full text-zinc-600 active:bg-zinc-100 dark:text-zinc-300 dark:active:bg-ink-700"
        >
          <Icon name="text" size={19} />
        </button>
        <button
          onClick={() => toggleSave(post)}
          className={`grid h-9 w-9 place-items-center rounded-full active:bg-zinc-100 dark:active:bg-ink-700 ${
            saved ? "text-brand-600" : "text-zinc-600 dark:text-zinc-300"
          }`}
        >
          <Icon name="bookmark" size={19} filled={saved} />
        </button>
        <button
          onClick={() => setShareSheet(true)}
          className="grid h-9 w-9 place-items-center rounded-full text-zinc-600 active:bg-zinc-100 dark:text-zinc-300 dark:active:bg-ink-700"
        >
          <Icon name="share" size={18} />
        </button>
        <div
          className="absolute inset-x-0 bottom-0 h-[3px] bg-brand-600 transition-[width] duration-150"
          style={{ width: `${progress}%` }}
        />
      </div>

      <div ref={scroller} onScroll={onScroll} className="no-scrollbar flex-1 overflow-y-auto">
        {image && (
          <Thumb post={{ ...post, image }} rounded="rounded-none" className="h-52 w-full" />
        )}

        <div className="px-4 pt-4">
          <h1 className="font-serif-bn text-[22px] font-bold leading-snug text-zinc-900 dark:text-zinc-50">
            {post.title}
          </h1>

          <div className="mt-3 flex items-center gap-2.5 border-y border-zinc-100 py-2.5 dark:border-ink-700">
            <div
              className="grid h-9 w-9 shrink-0 place-items-center rounded-full text-[11px] font-bold text-white"
              style={{ background: post.external ? src?.color ?? "#475569" : "#b00d1b" }}
            >
              {post.external ? src?.short ?? "WW" : "চাঁ"}
            </div>
            <div className="min-w-0 flex-1 leading-tight">
              <p className="truncate text-[12.5px] font-semibold text-zinc-800 dark:text-zinc-100">
                {post.source}
              </p>
              <p className="text-[11px] text-zinc-400">
                {banglaShortDate(new Date(post.dateISO))} · {clockHHMM(new Date(post.dateISO))} ·{" "}
                {timeAgo(post.minutesAgo)}
              </p>
            </div>
            <span className="shrink-0 rounded-full bg-zinc-100 px-2 py-1 text-[10.5px] font-semibold text-zinc-500 dark:bg-ink-700 dark:text-zinc-300">
              {toBn(readMins)} মিনিট
            </span>
          </div>

          {post.excerpt && (
            <p className="mt-4 border-l-4 border-brand-500 bg-brand-50/60 py-2 pl-3 font-serif-bn text-[14.5px] font-medium leading-relaxed text-zinc-700 dark:bg-ink-800 dark:text-zinc-200">
              {post.excerpt}
            </p>
          )}

          {/* body */}
          {loadingBody && !bodyHtml ? (
            <div className="mt-5 space-y-2.5">
              {[0, 1, 2, 3, 4, 5].map((i) => (
                <div
                  key={i}
                  className="shimmer relative h-3.5 overflow-hidden rounded bg-zinc-200 dark:bg-ink-700"
                  style={{ width: `${[100, 96, 88, 100, 92, 60][i]}%` }}
                />
              ))}
            </div>
          ) : bodyHtml ? (
            <div
              className={`article-body mt-4 ${
                dark ? "prose-invert" : ""
              } text-zinc-700 dark:text-zinc-300 [&_a]:text-brand-600 [&_a]:underline [&_blockquote]:border-l-4 [&_blockquote]:border-brand-400 [&_blockquote]:pl-3 [&_blockquote]:italic [&_figure]:my-3 [&_h2]:mb-2 [&_h2]:mt-5 [&_h2]:text-[18px] [&_h2]:font-bold [&_h3]:mb-2 [&_h3]:mt-4 [&_h3]:text-[16px] [&_h3]:font-bold [&_img]:my-3 [&_img]:w-full [&_img]:rounded-xl [&_li]:mb-1 [&_ol]:list-decimal [&_ol]:pl-5 [&_strong]:font-bold [&_ul]:list-disc [&_ul]:pl-5`}
              style={{ fontSize: fontPx, lineHeight: 1.95 }}
              dangerouslySetInnerHTML={{ __html: bodyHtml }}
            />
          ) : (
            <p className="mt-4 text-[14px] leading-relaxed text-zinc-500">{post.excerpt}</p>
          )}

          {/* source link */}
          <a
            href={post.link}
            target="_blank"
            rel="noreferrer"
            className="mt-6 flex items-center justify-center gap-2 rounded-xl py-3 text-[13.5px] font-bold text-white active:scale-95"
            style={{ background: post.external ? src?.color ?? "#334155" : "#b00d1b" }}
          >
            <Icon name="external" size={16} />
            {post.external ? `${post.source}-এ সম্পূর্ণ পড়ুন` : "ওয়েবসাইটে দেখুন"}
          </a>

          {/* categories */}
          {post.catNames.length > 0 && (
            <div className="mt-5 flex flex-wrap gap-2">
              {post.catNames.map((t) => {
                const s = catStyle(t);
                return (
                  <span
                    key={t}
                    className="rounded-full px-3 py-1 text-[12px] font-medium"
                    style={{
                      color: s.color,
                      background: `color-mix(in srgb, ${s.color} 13%, transparent)`,
                    }}
                  >
                    {s.icon} {t}
                  </span>
                );
              })}
            </div>
          )}

          {/* reactions */}
          <div className="mt-5 rounded-2xl bg-zinc-50 p-3 dark:bg-ink-800">
            <p className="mb-2 text-center text-[12.5px] font-semibold text-zinc-500 dark:text-zinc-400">
              এই সংবাদ সম্পর্কে আপনার প্রতিক্রিয়া
            </p>
            <div className="flex justify-center gap-2">
              {[
                ["👍", "ভালো"],
                ["😢", "দুঃখজনক"],
                ["😡", "ক্ষুব্ধ"],
                ["😮", "অবাক"],
              ].map(([e, label]) => (
                <button
                  key={label}
                  onClick={() => {
                    setReaction(label);
                    haptic();
                  }}
                  className={`flex flex-col items-center gap-0.5 rounded-xl px-3 py-2 transition active:scale-90 ${
                    reaction === label
                      ? "bg-brand-100 ring-1 ring-brand-300 dark:bg-ink-700"
                      : "bg-white dark:bg-ink-700/50"
                  }`}
                >
                  <span className="text-[20px]">{e}</span>
                  <span className="text-[10.5px] text-zinc-500 dark:text-zinc-400">{label}</span>
                </button>
              ))}
            </div>
          </div>

          {/* share row */}
          <div className="mt-4 flex items-center gap-2">
            <span className="text-[12.5px] font-semibold text-zinc-500">শেয়ার:</span>
            {[
              ["ফেসবুক", "#1877f2"],
              ["হোয়াটসঅ্যাপ", "#25d366"],
              ["এক্স", "#0f172a"],
            ].map(([label, color]) => (
              <button
                key={label}
                onClick={() => share(label)}
                className="rounded-full px-3 py-1.5 text-[11.5px] font-semibold text-white active:scale-95"
                style={{ background: color }}
              >
                {label}
              </button>
            ))}
            <button
              onClick={() => share("copy")}
              className="ml-auto grid h-8 w-8 place-items-center rounded-full bg-zinc-100 text-zinc-500 dark:bg-ink-700 dark:text-zinc-300"
            >
              <Icon name="copy" size={15} />
            </button>
          </div>
        </div>

        {/* related */}
        {related.length > 0 && (
          <div className="mt-6 border-t-8 border-zinc-100 pt-4 dark:border-ink-800">
            <h3 className="mb-1 px-4 text-[15px] font-bold text-zinc-900 dark:text-zinc-50">
              আরও পড়ুন
            </h3>
            <div className="divide-y divide-zinc-100 pb-8 dark:divide-ink-700/60">
              {related.map((r) => (
                <NewsCard key={r.id} post={r} onOpen={onOpen} />
              ))}
            </div>
          </div>
        )}
      </div>

      <Sheet open={fontSheet} onClose={() => setFontSheet(false)} title="লেখার আকার">
        <div className="pt-2">
          <div className="flex items-center gap-3">
            <span className="text-[13px] text-zinc-400">অ</span>
            <input
              type="range"
              min={0}
              max={4}
              step={1}
              value={fontStep}
              onChange={(e) => set("fontStep", Number(e.target.value))}
              className="h-1.5 flex-1 accent-brand-600"
            />
            <span className="text-[22px] text-zinc-500">অ</span>
          </div>
          <p
            className="mt-4 rounded-xl bg-zinc-50 p-3 font-bangla leading-relaxed text-zinc-600 dark:bg-ink-700 dark:text-zinc-300"
            style={{ fontSize: fontPx }}
          >
            নমুনা: চাঁন্দাবাজ বিডি অ্যাপে সংবাদ পড়ার অভিজ্ঞতা আপনার পছন্দমতো সাজিয়ে নিন।
          </p>
        </div>
      </Sheet>

      <Sheet open={shareSheet} onClose={() => setShareSheet(false)} title="শেয়ার করুন">
        <div className="grid grid-cols-4 gap-3 pt-3">
          {[
            ["ফেসবুক", "📘"],
            ["হোয়াটসঅ্যাপ", "💬"],
            ["এক্স", "✖️"],
            ["টেলিগ্রাম", "📨"],
            ["ইমেইল", "📧"],
            ["native", "📱"],
            ["copy", "🔗"],
          ].map(([key, emoji]) => (
            <button
              key={key}
              onClick={() => share(key)}
              className="flex flex-col items-center gap-1.5 rounded-xl bg-zinc-50 py-3 active:scale-95 dark:bg-ink-700"
            >
              <span className="text-[22px]">{emoji}</span>
              <span className="text-[10.5px] font-medium text-zinc-600 dark:text-zinc-300">
                {key === "native" ? "অন্যান্য" : key === "copy" ? "লিংক কপি" : key}
              </span>
            </button>
          ))}
        </div>
        <p className="mt-4 truncate rounded-lg bg-zinc-100 px-3 py-2 text-[11.5px] text-zinc-500 dark:bg-ink-700 dark:text-zinc-400">
          {post.link}
        </p>
      </Sheet>
    </div>
  );
}
