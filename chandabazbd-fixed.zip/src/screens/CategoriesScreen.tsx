import { useState } from "react";
import type { Post, WpCategory } from "@/lib/api";
import { usePostFeed } from "@/lib/useNews";
import NewsCard from "@/components/NewsCard";
import { Icon } from "@/components/Icons";
import { EmptyState, SkeletonCard } from "@/components/ui";
import { toBn } from "@/lib/utils";
import { catStyle } from "@/data/catMeta";

export function CategoriesScreen({
  cats,
  onOpenCategory,
}: {
  cats: WpCategory[];
  onOpenCategory: (c: WpCategory) => void;
}) {
  return (
    <div className="no-scrollbar h-full overflow-y-auto bg-zinc-50 pb-6 dark:bg-ink-900">
      <div className="bg-gradient-to-br from-brand-700 to-brand-600 px-4 pb-5 pt-4 text-white">
        <h2 className="text-[18px] font-bold">সব বিভাগ</h2>
        <p className="text-[12px] text-white/75">
          chandabazbd.com-এর {toBn(cats.length)} টি বিভাগ
        </p>
      </div>

      {!cats.length ? (
        <div className="grid grid-cols-2 gap-2.5 p-4">
          {Array.from({ length: 8 }).map((_, i) => (
            <div key={i} className="h-28 animate-pulse rounded-2xl bg-zinc-200 dark:bg-ink-700" />
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-2 gap-2.5 p-4">
          {cats.map((c) => {
            const s = catStyle(c.slug) ?? catStyle(c.name);
            const style = s.icon === "📰" ? catStyle(c.name) : s;
            return (
              <button
                key={c.id}
                onClick={() => onOpenCategory(c)}
                className="relative overflow-hidden rounded-2xl bg-white p-3.5 text-left shadow-sm ring-1 ring-zinc-200/70 active:scale-[0.97] dark:bg-ink-800 dark:ring-ink-700"
              >
                <span
                  className="absolute -right-6 -top-6 h-16 w-16 rounded-full opacity-15"
                  style={{ background: style.color }}
                />
                <div
                  className="grid h-10 w-10 place-items-center rounded-xl text-[19px]"
                  style={{ background: `color-mix(in srgb, ${style.color} 16%, transparent)` }}
                >
                  {style.icon}
                </div>
                <h3 className="mt-2.5 line-clamp-1 text-[14.5px] font-bold text-zinc-800 dark:text-zinc-100">
                  {c.name}
                </h3>
                <p className="text-[11px] text-zinc-400">{toBn(c.count)} টি সংবাদ</p>
                <Icon
                  name="chevron"
                  size={14}
                  className="absolute bottom-3.5 right-3 text-zinc-300 dark:text-ink-600"
                />
              </button>
            );
          })}
        </div>
      )}
    </div>
  );
}

export function CategoryDetailScreen({
  cat,
  catMap,
  onBack,
  onOpen,
}: {
  cat: WpCategory;
  catMap: Map<number, string>;
  onBack: () => void;
  onOpen: (p: Post) => void;
}) {
  const [sort, setSort] = useState<"new" | "old">("new");
  const { posts, state, loadMore, loadingMore, hasMore, refresh } = usePostFeed(catMap, {
    categoryId: cat.id,
    perPage: 14,
    cacheKey: `cat-${cat.id}`,
  });
  const style = catStyle(cat.slug).icon === "📰" ? catStyle(cat.name) : catStyle(cat.slug);
  const list = sort === "new" ? posts : [...posts].reverse();

  return (
    <div className="animate-screen-in flex h-full flex-col bg-zinc-50 dark:bg-ink-900">
      <div
        className="flex items-center gap-2 px-3 pb-3 pt-3 text-white"
        style={{ background: `linear-gradient(135deg, ${style.color}, ${style.color}cc)` }}
      >
        <button onClick={onBack} className="grid h-9 w-9 place-items-center rounded-full bg-white/15">
          <Icon name="back" size={19} />
        </button>
        <div className="min-w-0 flex-1">
          <h2 className="truncate text-[17px] font-bold leading-tight">
            {style.icon} {cat.name}
          </h2>
          <p className="text-[11px] text-white/75">{toBn(cat.count)} টি সংবাদ</p>
        </div>
      </div>

      <div className="flex gap-2 border-b border-zinc-200 bg-white px-4 py-2 dark:border-ink-700 dark:bg-ink-800">
        {([
          ["new", "নতুন আগে"],
          ["old", "পুরনো আগে"],
        ] as const).map(([k, label]) => (
          <button
            key={k}
            onClick={() => setSort(k)}
            className={`rounded-full px-3 py-1 text-[12.5px] font-semibold ${
              sort === k
                ? "bg-zinc-900 text-white dark:bg-zinc-100 dark:text-zinc-900"
                : "bg-zinc-100 text-zinc-500 dark:bg-ink-700 dark:text-zinc-400"
            }`}
          >
            {label}
          </button>
        ))}
      </div>

      <div
        className="no-scrollbar flex-1 overflow-y-auto pb-6"
        onScroll={(e) => {
          const el = e.currentTarget;
          if (hasMore && !loadingMore && el.scrollTop + el.clientHeight >= el.scrollHeight - 380)
            loadMore();
        }}
      >
        {state === "loading" && !posts.length ? (
          <>
            <SkeletonCard />
            <SkeletonCard />
            <SkeletonCard />
            <SkeletonCard />
          </>
        ) : !list.length ? (
          <EmptyState
            icon="📭"
            title="এই বিভাগে সংবাদ নেই"
            text="পরে আবার দেখুন অথবা অন্য বিভাগ ব্রাউজ করুন।"
            actionLabel="আবার চেষ্টা"
            onAction={refresh}
          />
        ) : (
          <>
            <div className="p-4">
              <NewsCard post={list[0]} onOpen={onOpen} variant="big" />
            </div>
            <div className="divide-y divide-zinc-100 bg-white dark:divide-ink-700/60 dark:bg-ink-800/40">
              {list.slice(1).map((p) => (
                <NewsCard key={p.id} post={p} onOpen={onOpen} />
              ))}
            </div>
            {loadingMore && <SkeletonCard />}
          </>
        )}
      </div>
    </div>
  );
}
