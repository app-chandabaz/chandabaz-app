import { useEffect, useMemo, useRef, useState } from "react";
import type { Post, WpCategory } from "@/lib/api";
import { usePostFeed } from "@/lib/useNews";
import NewsCard from "@/components/NewsCard";
import { CategoryStrip } from "@/components/Chrome";
import { EmptyState, SectionHeader, SkeletonCard } from "@/components/ui";
import { Icon } from "@/components/Icons";
import { haptic, timeAgo, toBn } from "@/lib/utils";
import { useApp } from "@/lib/store";
import WorldStrip from "@/components/WorldStrip";

interface Props {
  cats: WpCategory[];
  catMap: Map<number, string>;
  onOpen: (p: Post) => void;
  onOpenCategory: (c: WpCategory) => void;
  onGoWorld: () => void;
  onLatest?: (posts: Post[]) => void;
}

export default function HomeScreen({
  cats,
  catMap,
  onOpen,
  onOpenCategory,
  onGoWorld,
  onLatest,
}: Props) {
  const { toast } = useApp();
  const [activeCat, setActiveCat] = useState<number | null>(null);
  const [pull, setPull] = useState(0);
  const [slide, setSlide] = useState(0);
  const startY = useRef<number | null>(null);
  const scroller = useRef<HTMLDivElement>(null);

  const { posts, state, refresh, loadMore, loadingMore, hasMore, fromCache } = usePostFeed(
    catMap,
    {
      categoryId: activeCat ?? undefined,
      perPage: 14,
      cacheKey: activeCat ? `cat-${activeCat}` : "home",
    }
  );

  const hero = useMemo(() => posts.slice(0, 5), [posts]);
  const rest = useMemo(() => posts.slice(5), [posts]);

  useEffect(() => {
    if (hero.length < 2) return;
    const t = setInterval(() => setSlide((s) => (s + 1) % hero.length), 5000);
    return () => clearInterval(t);
  }, [hero.length]);

  useEffect(() => setSlide(0), [activeCat]);

  /* সর্বশেষ পোস্ট প্যারেন্টে পাঠানো (টিকার ও নোটিফিকেশনের জন্য) */
  useEffect(() => {
    if (!activeCat && posts.length) onLatest?.(posts.slice(0, 8));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [posts, activeCat]);

  /* pull to refresh */
  const onTouchStart = (e: React.TouchEvent) => {
    if ((scroller.current?.scrollTop ?? 0) <= 0) startY.current = e.touches[0].clientY;
  };
  const onTouchMove = (e: React.TouchEvent) => {
    if (startY.current === null || state === "loading") return;
    const d = e.touches[0].clientY - startY.current;
    if (d > 0) setPull(Math.min(d * 0.45, 86));
  };
  const onTouchEnd = () => {
    if (pull > 56) {
      haptic(18);
      refresh();
      toast("সর্বশেষ সংবাদ আনা হচ্ছে...", "🔄");
    }
    setPull(0);
    startY.current = null;
  };

  /* infinite scroll */
  const onScroll = () => {
    const el = scroller.current;
    if (!el || !hasMore || loadingMore) return;
    if (el.scrollTop + el.clientHeight >= el.scrollHeight - 420) loadMore();
  };

  const busy = state === "loading" && !posts.length;

  return (
    <div className="flex h-full flex-col bg-zinc-50 dark:bg-ink-900">
      <CategoryStrip cats={cats} active={activeCat} onSelect={setActiveCat} />

      <div
        ref={scroller}
        onScroll={onScroll}
        onTouchStart={onTouchStart}
        onTouchMove={onTouchMove}
        onTouchEnd={onTouchEnd}
        className="no-scrollbar flex-1 overflow-y-auto overscroll-contain pb-6"
        style={{ transform: `translateY(${pull}px)`, transition: pull ? "none" : "transform .3s" }}
      >
        <div
          className="flex items-center justify-center overflow-hidden text-brand-600 dark:text-brand-400"
          style={{ height: Math.max(pull - 6, 0) }}
        >
          <Icon name="refresh" size={18} style={{ transform: `rotate(${pull * 4}deg)` }} />
          <span className="ml-2 text-[12px] font-semibold">
            {pull > 56 ? "ছেড়ে দিন" : "টেনে রিফ্রেশ করুন"}
          </span>
        </div>

        {fromCache && (
          <div className="flex items-center justify-center gap-1.5 bg-amber-50 py-1.5 text-[11px] font-medium text-amber-700 dark:bg-amber-500/10 dark:text-amber-400">
            <Icon name="clock" size={12} /> সংরক্ষিত কপি দেখানো হচ্ছে — আপডেট হচ্ছে...
          </div>
        )}

        {busy ? (
          <div className="pt-2">
            <div className="mx-4 mb-3 h-52 animate-pulse rounded-2xl bg-zinc-200 dark:bg-ink-700" />
            <SkeletonCard />
            <SkeletonCard />
            <SkeletonCard />
            <SkeletonCard />
          </div>
        ) : state === "error" && !posts.length ? (
          <EmptyState
            icon="📡"
            title="সংবাদ আনা যায়নি"
            text="ইন্টারনেট সংযোগ পরীক্ষা করে আবার চেষ্টা করুন। chandabazbd.com সার্ভারের সাথে সংযোগ করা যাচ্ছে না।"
            actionLabel="আবার চেষ্টা করুন"
            onAction={refresh}
          />
        ) : (
          <>
            {/* hero carousel */}
            {hero.length > 0 && (
              <div className="px-4 pt-3">
                <div className="relative overflow-hidden rounded-2xl">
                  <div
                    className="flex transition-transform duration-500 ease-out"
                    style={{ transform: `translateX(-${slide * 100}%)` }}
                  >
                    {hero.map((p) => (
                      <div key={p.id} className="w-full shrink-0">
                        <NewsCard post={p} onOpen={onOpen} variant="hero" />
                      </div>
                    ))}
                  </div>
                  <div className="absolute bottom-2 right-3 flex gap-1.5">
                    {hero.map((_, i) => (
                      <button
                        key={i}
                        onClick={() => setSlide(i)}
                        className={`h-1.5 rounded-full transition-all ${
                          i === slide ? "w-5 bg-white" : "w-1.5 bg-white/50"
                        }`}
                      />
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* live stats */}
            <div className="mt-4 grid grid-cols-3 gap-2 px-4">
              {[
                { k: "প্রকাশিত খবর", v: toBn(posts.length), i: "📰" },
                { k: "বিভাগ", v: toBn(cats.length), i: "🗂️" },
                { k: "সর্বশেষ", v: posts[0] ? timeAgo(posts[0].minutesAgo) : "—", i: "⏱️" },
              ].map((s) => (
                <div
                  key={s.k}
                  className="rounded-xl bg-white px-2 py-2.5 text-center shadow-sm ring-1 ring-zinc-200/70 dark:bg-ink-800 dark:ring-ink-700"
                >
                  <div className="text-[15px]">{s.i}</div>
                  <div className="truncate text-[13px] font-bold text-zinc-800 dark:text-zinc-100">
                    {s.v}
                  </div>
                  <div className="text-[10px] text-zinc-400">{s.k}</div>
                </div>
              ))}
            </div>

            {/* international */}
            {!activeCat && <WorldStrip onOpen={onOpen} onSeeAll={onGoWorld} />}

            {/* main feed */}
            <div className="mt-5">
              <SectionHeader
                title={
                  activeCat
                    ? cats.find((c) => c.id === activeCat)?.name ?? "সংবাদ"
                    : "সর্বশেষ সংবাদ"
                }
                action={activeCat ? "বিভাগে যান" : undefined}
                onAction={() => {
                  const c = cats.find((x) => x.id === activeCat);
                  if (c) onOpenCategory(c);
                }}
              />
              <div className="divide-y divide-zinc-100 bg-white dark:divide-ink-700/60 dark:bg-ink-800/40">
                {rest.slice(0, 6).map((p) => (
                  <NewsCard key={p.id} post={p} onOpen={onOpen} />
                ))}
              </div>
            </div>

            {/* featured break */}
            {rest[6] && (
              <div className="mt-5 px-4">
                <NewsCard post={rest[6]} onOpen={onOpen} variant="big" />
              </div>
            )}

            {rest.length > 7 && (
              <div className="mt-5">
                <SectionHeader title="আরও সংবাদ" accent="#0f766e" />
                <div className="divide-y divide-zinc-100 bg-white dark:divide-ink-700/60 dark:bg-ink-800/40">
                  {rest.slice(7).map((p) => (
                    <NewsCard key={p.id} post={p} onOpen={onOpen} />
                  ))}
                </div>
              </div>
            )}

            {loadingMore && (
              <>
                <SkeletonCard />
                <SkeletonCard />
              </>
            )}

            {!hasMore && posts.length > 0 && (
              <p className="px-6 pb-4 pt-8 text-center text-[11px] leading-relaxed text-zinc-400">
                সব সংবাদ দেখা হয়েছে
                <br />© {toBn(2026)} চাঁদাবাজ বিডি · chandabazbd.com
              </p>
            )}
          </>
        )}
      </div>
    </div>
  );
}
