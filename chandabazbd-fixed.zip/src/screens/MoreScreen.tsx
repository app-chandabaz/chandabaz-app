import { useEffect, useState, type ReactNode } from "react";
import { Icon, Logo } from "@/components/Icons";
import { Sheet, Switch } from "@/components/ui";
import { useApp } from "@/lib/store";
import { toBn } from "@/lib/utils";
import { checkConnection, SITE } from "@/lib/api";
import { SOURCES } from "@/lib/world";
import { cn } from "@/utils/cn";

function Row({
  icon,
  label,
  sub,
  right,
  onClick,
  color = "#de1f26",
}: {
  icon: string;
  label: string;
  sub?: string;
  right?: ReactNode;
  onClick?: () => void;
  color?: string;
}) {
  return (
    <button
      onClick={onClick}
      className="flex w-full items-center gap-3 px-4 py-3 text-left active:bg-zinc-50 dark:active:bg-ink-700/40"
    >
      <span
        className="grid h-9 w-9 shrink-0 place-items-center rounded-xl"
        style={{ background: `color-mix(in srgb, ${color} 14%, transparent)`, color }}
      >
        <Icon name={icon} size={18} />
      </span>
      <span className="min-w-0 flex-1">
        <span className="block text-[13.5px] font-semibold text-zinc-800 dark:text-zinc-100">
          {label}
        </span>
        {sub && <span className="block text-[11px] text-zinc-400">{sub}</span>}
      </span>
      {right ?? <Icon name="chevron" size={15} className="text-zinc-300 dark:text-ink-600" />}
    </button>
  );
}

function Group({ title, children }: { title: string; children: ReactNode }) {
  return (
    <div className="mt-4">
      <h3 className="mb-1.5 px-4 text-[11.5px] font-bold uppercase tracking-wide text-zinc-400">
        {title}
      </h3>
      <div className="divide-y divide-zinc-100 bg-white dark:divide-ink-700/60 dark:bg-ink-800">
        {children}
      </div>
    </div>
  );
}

export default function MoreScreen({
  canInstall,
  onInstall,
  onGoWorld,
}: {
  canInstall: boolean;
  onInstall: () => void;
  onGoWorld: () => void;
}) {
  const {
    dark,
    set,
    pushBreaking,
    pushSports,
    pushDaily,
    dataSaver,
    fontStep,
    toast,
    saved,
    history,
    worldSources,
  } = useApp();
  const [sheet, setSheet] = useState<null | "about" | "contact" | "privacy" | "api">(null);
  const [conn, setConn] = useState<{ connected: boolean; name?: string; version?: string } | null>(
    null
  );

  useEffect(() => {
    checkConnection().then(setConn);
  }, []);

  const share = async () => {
    const data = {
      title: "চাঁন্দাবাজ বিডি নিউজ অ্যাপ",
      text: "বাংলাদেশের সর্বশেষ সংবাদ পড়ুন চাঁন্দাবাজ বিডি অ্যাপে",
      url: SITE,
    };
    if (navigator.share) {
      try {
        await navigator.share(data);
        return;
      } catch {
        /* cancelled */
      }
    }
    try {
      await navigator.clipboard.writeText(data.url);
      toast("অ্যাপ লিংক কপি হয়েছে", "🔗");
    } catch {
      toast("শেয়ার করা যায়নি", "⚠️");
    }
  };

  return (
    <div className="no-scrollbar h-full overflow-y-auto bg-zinc-50 pb-8 dark:bg-ink-900">
      {/* profile */}
      <div className="bg-gradient-to-br from-brand-800 via-brand-700 to-brand-600 px-4 pb-6 pt-5 text-white">
        <div className="flex items-center gap-3">
          <div className="grid h-14 w-14 place-items-center rounded-2xl bg-white/15 text-[26px] ring-1 ring-white/25">
            👤
          </div>
          <div className="flex-1">
            <h2 className="text-[16.5px] font-bold">অতিথি পাঠক</h2>
            <p className="text-[11.5px] text-white/75">
              {toBn(saved.length)} সংরক্ষিত · {toBn(history.length)} পড়া হয়েছে
            </p>
          </div>
          <button
            onClick={() => toast("লগইন সুবিধা শীঘ্রই আসছে", "🔐")}
            className="rounded-full bg-white px-3.5 py-1.5 text-[12.5px] font-bold text-brand-700 active:scale-95"
          >
            লগইন
          </button>
        </div>

        {/* live connection status */}
        <div className="mt-4 flex items-center gap-2.5 rounded-xl bg-white/12 px-3 py-2.5">
          <span
            className={cn(
              "h-2.5 w-2.5 shrink-0 rounded-full",
              conn === null
                ? "animate-pulse bg-amber-300"
                : conn.connected
                  ? "animate-pulse bg-emerald-400"
                  : "bg-rose-400"
            )}
          />
          <div className="min-w-0 flex-1 leading-tight">
            <p className="text-[12px] font-semibold">
              {conn === null
                ? "সংযোগ যাচাই হচ্ছে..."
                : conn.connected
                  ? "API সংযুক্ত — লাইভ কনটেন্ট"
                  : "API সংযোগ বিচ্ছিন্ন"}
            </p>
            <p className="truncate text-[10px] text-white/65">
              chandabazbd.com
              {conn?.version ? ` · ${conn.name} v${conn.version}` : ""}
            </p>
          </div>
          <button
            onClick={() => setSheet("api")}
            className="shrink-0 rounded-full bg-white/20 px-2.5 py-1 text-[10.5px] font-bold"
          >
            বিস্তারিত
          </button>
        </div>

        <div className="mt-3 grid grid-cols-4 gap-2">
          {[
            ["🌍", "আন্তর্জাতিক", onGoWorld],
            ["🔔", "অ্যালার্ট", () => toast("নোটিফিকেশন সেটিংস নিচে", "🔔")],
            ["🔗", "API", () => setSheet("api")],
            ["🌐", "ওয়েবসাইট", () => window.open(SITE, "_blank")],
          ].map(([icon, label, fn]) => (
            <button
              key={label as string}
              onClick={fn as () => void}
              className="flex flex-col items-center gap-1 rounded-xl bg-white/12 py-2.5 active:scale-95"
            >
              <span className="text-[19px]">{icon as string}</span>
              <span className="text-[10px] font-medium">{label as string}</span>
            </button>
          ))}
        </div>
      </div>

      {canInstall && (
        <button
          onClick={onInstall}
          className="mx-4 -mt-4 flex w-[calc(100%-2rem)] items-center gap-3 rounded-2xl bg-white p-3 shadow-lg ring-1 ring-zinc-200 active:scale-[0.99] dark:bg-ink-800 dark:ring-ink-700"
        >
          <Logo size={38} />
          <span className="flex-1 text-left">
            <span className="block text-[13.5px] font-bold text-zinc-800 dark:text-zinc-100">
              অ্যাপটি ফোনে ইনস্টল করুন
            </span>
            <span className="block text-[11px] text-zinc-400">
              হোম স্ক্রিনে যোগ করুন · অফলাইনেও চলবে
            </span>
          </span>
          <span className="rounded-full bg-brand-600 px-3 py-1.5 text-[12px] font-bold text-white">
            ইনস্টল
          </span>
        </button>
      )}

      <Group title="সেটিংস">
        <Row
          icon={dark ? "moon" : "sun"}
          label="ডার্ক মোড"
          sub="রাতে চোখের আরামের জন্য"
          color="#4338ca"
          right={<Switch checked={dark} onChange={(v) => set("dark", v)} />}
        />
        <div className="px-4 py-3">
          <div className="mb-2 flex items-center gap-3">
            <span className="grid h-9 w-9 place-items-center rounded-xl bg-teal-500/15 text-teal-600">
              <Icon name="text" size={18} />
            </span>
            <span className="flex-1 text-[13.5px] font-semibold text-zinc-800 dark:text-zinc-100">
              লেখার আকার
            </span>
            <span className="text-[11.5px] text-zinc-400">
              {["খুব ছোট", "ছোট", "মাঝারি", "বড়", "খুব বড়"][fontStep]}
            </span>
          </div>
          <input
            type="range"
            min={0}
            max={4}
            value={fontStep}
            onChange={(e) => set("fontStep", Number(e.target.value))}
            className="h-1.5 w-full accent-brand-600"
          />
        </div>
        <Row
          icon="wifiOff"
          label="ডেটা সেভার"
          sub="ছবি বন্ধ রেখে কম ডেটায় পড়ুন"
          color="#15803d"
          right={<Switch checked={dataSaver} onChange={(v) => set("dataSaver", v)} />}
        />
      </Group>

      <Group title="নোটিফিকেশন">
        <Row
          icon="bolt"
          label="সর্বশেষ সংবাদ"
          sub="নতুন খবর প্রকাশ হলে জানান"
          color="#de1f26"
          right={<Switch checked={pushBreaking} onChange={(v) => set("pushBreaking", v)} />}
        />
        <Row
          icon="globe"
          label="আন্তর্জাতিক আপডেট"
          sub="বিদেশি সোর্সের গুরুত্বপূর্ণ খবর"
          color="#0891b2"
          right={<Switch checked={pushSports} onChange={(v) => set("pushSports", v)} />}
        />
        <Row
          icon="mail"
          label="দৈনিক ডাইজেস্ট"
          sub="প্রতিদিন সকাল ৮টায় সারসংক্ষেপ"
          color="#b45309"
          right={<Switch checked={pushDaily} onChange={(v) => set("pushDaily", v)} />}
        />
      </Group>

      <Group title="কনটেন্ট সোর্স">
        <Row
          icon="shield"
          label="চাঁন্দাবাজ বিডি (প্রধান)"
          sub={conn?.connected ? "✅ লাইভ সংযুক্ত" : "WordPress REST API"}
          color="#b00d1b"
          onClick={() => setSheet("api")}
        />
        <Row
          icon="globe"
          label="আন্তর্জাতিক সোর্স"
          sub={`${toBn(worldSources.length)} টি সক্রিয় · ${SOURCES.filter((s) => worldSources.includes(s.id))
            .map((s) => s.name)
            .join(", ")}`}
          color="#0891b2"
          onClick={onGoWorld}
        />
      </Group>

      <Group title="চাঁন্দাবাজ বিডি সম্পর্কে">
        <Row icon="info" label="আমাদের সম্পর্কে" color="#0f766e" onClick={() => setSheet("about")} />
        <Row
          icon="phone"
          label="যোগাযোগ ও বিজ্ঞাপন"
          color="#1d4ed8"
          onClick={() => setSheet("contact")}
        />
        <Row icon="shield" label="গোপনীয়তা নীতি" color="#475569" onClick={() => setSheet("privacy")} />
        <Row
          icon="external"
          label="ওয়েবসাইট ভিজিট করুন"
          sub="chandabazbd.com"
          color="#be185d"
          onClick={() => window.open(SITE, "_blank")}
        />
      </Group>

      <Group title="অ্যাপ">
        <Row icon="share" label="বন্ধুদের সাথে শেয়ার করুন" color="#15803d" onClick={share} />
        <Row
          icon="download"
          label="হোম স্ক্রিনে যোগ করুন"
          sub={canInstall ? "এক ট্যাপে ইনস্টল" : "ব্রাউজার মেনু → Add to Home screen"}
          color="#4338ca"
          onClick={() => (canInstall ? onInstall() : toast("ব্রাউজার মেনু থেকে যোগ করুন", "📲"))}
        />
        <Row
          icon="trash"
          label="ক্যাশ পরিষ্কার করুন"
          sub="সংরক্ষিত কপি ও ছবি মুছে ফেলুন"
          color="#be123c"
          onClick={() => {
            try {
              localStorage.removeItem("chandabazbd:cache:v2");
            } catch {
              /* noop */
            }
            toast("ক্যাশ পরিষ্কার হয়েছে", "🧹");
          }}
        />
      </Group>

      <div className="mt-6 flex justify-center gap-3">
        {[
          ["f", "#1877f2"],
          ["▶", "#ff0000"],
          ["✖", "#0f172a"],
          ["in", "#0a66c2"],
          ["✆", "#25d366"],
        ].map(([t, c]) => (
          <button
            key={t}
            onClick={() => toast("সোশ্যাল মিডিয়ায় ফলো করুন", "👍")}
            className="grid h-10 w-10 place-items-center rounded-full text-[15px] font-bold text-white active:scale-90"
            style={{ background: c }}
          >
            {t}
          </button>
        ))}
      </div>

      <p className="mt-5 text-center text-[11px] leading-relaxed text-zinc-400">
        চাঁন্দাবাজ বিডি অ্যাপ · সংস্করণ {toBn("2.0.0")}
        <br />
        সত্য ও বস্তুনিষ্ঠ সংবাদ পরিবেশনে প্রতিশ্রুতিবদ্ধ
        <br />© {toBn(2026)} chandabazbd.com — সর্বস্বত্ব সংরক্ষিত
      </p>

      {/* API sheet */}
      <Sheet open={sheet === "api"} onClose={() => setSheet(null)} title="API সংযোগ">
        <div className="space-y-2.5 py-2 text-[12.5px] text-zinc-600 dark:text-zinc-300">
          <div
            className={cn(
              "flex items-center gap-2 rounded-xl p-3",
              conn?.connected
                ? "bg-emerald-50 text-emerald-700 dark:bg-emerald-500/10 dark:text-emerald-400"
                : "bg-rose-50 text-rose-700 dark:bg-rose-500/10 dark:text-rose-400"
            )}
          >
            <Icon name={conn?.connected ? "check" : "close"} size={16} />
            <span className="text-[13px] font-bold">
              {conn?.connected ? "সফলভাবে সংযুক্ত" : "সংযোগ করা যায়নি"}
            </span>
          </div>
          {[
            ["সাইট", "chandabazbd.com"],
            ["সাইটের নাম", conn?.name ?? "—"],
            ["কনটেন্ট API", "wp/v2/posts (তালিকা)"],
            ["আর্টিকেল API", "wp/v2/posts/{id}"],
            ["ক্যাটাগরি API", "wp/v2/categories"],
            ["অনুসন্ধান", "wp/v2/posts?search="],
          ].map(([k, v]) => (
            <div
              key={k}
              className="flex items-center justify-between gap-3 rounded-lg bg-zinc-50 px-3 py-2 dark:bg-ink-700"
            >
              <span className="shrink-0 text-[11.5px] text-zinc-400">{k}</span>
              <span className="truncate font-medium text-zinc-700 dark:text-zinc-100">{v}</span>
            </div>
          ))}
          <p className="pt-1 text-[11px] leading-relaxed text-zinc-400">
            অ্যাপটি আপনার ওয়ার্ডপ্রেস সাইট থেকে সরাসরি লাইভ কনটেন্ট নিয়ে আসে। সাইটে নতুন পোস্ট
            প্রকাশ করলেই তা অ্যাপে দেখা যাবে — আলাদা কিছু করতে হবে না।
          </p>
        </div>
      </Sheet>

      <Sheet open={sheet === "about"} onClose={() => setSheet(null)} title="আমাদের সম্পর্কে">
        <div className="space-y-3 py-2 text-[13px] leading-relaxed text-zinc-600 dark:text-zinc-300">
          <p>
            <strong className="text-zinc-800 dark:text-zinc-100">চাঁন্দাবাজ বিডি ডট কম</strong> —
            সত্য ও বস্তুনিষ্ঠ সংবাদ পরিবেশনে প্রতিশ্রুতিবদ্ধ। দেশ-বিদেশের সর্বশেষ খবর ও বিশ্লেষণ
            পৌঁছে দিই পাঠকের হাতের মুঠোয়।
          </p>
          <p>
            রাজনীতি, জাতীয়, মধ্যপ্রাচ্য, বিশ্ব, অর্থনীতি, প্রবাসী সংবাদসহ সব বিভাগের খবর এক
            অ্যাপে। পাশাপাশি আন্তর্জাতিক সংবাদ সংস্থার খবরও একত্রে পাবেন।
          </p>
          <p className="rounded-xl bg-zinc-50 p-3 dark:bg-ink-700">
            🎯 আমাদের অঙ্গীকার: নির্ভুল তথ্য, নিরপেক্ষ উপস্থাপন ও দ্রুততম সংবাদ পরিবেশন।
          </p>
        </div>
      </Sheet>

      <Sheet open={sheet === "contact"} onClose={() => setSheet(null)} title="যোগাযোগ">
        <div className="space-y-2.5 py-2 text-[13px] text-zinc-600 dark:text-zinc-300">
          {[
            ["🌐", "ওয়েবসাইট", "www.chandabazbd.com"],
            ["✉️", "নিউজ ডেস্ক", "news@chandabazbd.com"],
            ["📢", "বিজ্ঞাপন", "ads@chandabazbd.com"],
            ["📞", "হটলাইন", "+৮৮০ ১৭০০-০০০০০০"],
          ].map(([i, k, v]) => (
            <div key={k} className="flex gap-3 rounded-xl bg-zinc-50 p-3 dark:bg-ink-700">
              <span className="text-[17px]">{i}</span>
              <div>
                <p className="text-[11.5px] text-zinc-400">{k}</p>
                <p className="font-medium text-zinc-700 dark:text-zinc-100">{v}</p>
              </div>
            </div>
          ))}
        </div>
      </Sheet>

      <Sheet open={sheet === "privacy"} onClose={() => setSheet(null)} title="গোপনীয়তা নীতি">
        <div className="space-y-3 py-2 text-[12.5px] leading-relaxed text-zinc-600 dark:text-zinc-300">
          <p>
            এই অ্যাপ ব্যবহারকারীর ব্যক্তিগত তথ্য সংগ্রহ করে না। আপনার সংরক্ষিত সংবাদ, পড়ার ইতিহাস
            ও সেটিংস শুধুমাত্র আপনার ডিভাইসেই সংরক্ষিত থাকে।
          </p>
          <p>
            আন্তর্জাতিক সংবাদ সংশ্লিষ্ট সংস্থার পাবলিক RSS ফিড থেকে সংগৃহীত। কপিরাইট সংশ্লিষ্ট
            সংস্থার।
          </p>
          <p>বিস্তারিত জানতে ভিজিট করুন chandabazbd.com</p>
        </div>
      </Sheet>
    </div>
  );
}
