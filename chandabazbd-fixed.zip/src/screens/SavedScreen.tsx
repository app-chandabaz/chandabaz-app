import { useState } from "react";
import type { Post } from "@/lib/api";
import NewsCard from "@/components/NewsCard";
import { EmptyState } from "@/components/ui";
import { useApp } from "@/lib/store";
import { toBn } from "@/lib/utils";
import { Icon } from "@/components/Icons";

export default function SavedScreen({
  onOpen,
  onGoHome,
}: {
  onOpen: (p: Post) => void;
  onGoHome: () => void;
}) {
  const { saved, history, set, toast } = useApp();
  const [tab, setTab] = useState<"saved" | "history">("saved");
  const list = tab === "saved" ? saved : history;

  return (
    <div className="flex h-full flex-col bg-zinc-50 dark:bg-ink-900">
      <div className="bg-gradient-to-br from-brand-700 to-brand-600 px-4 pb-3 pt-4 text-white">
        <h2 className="text-[18px] font-bold">আমার লাইব্রেরি</h2>
        <p className="text-[11.5px] text-white/75">অফলাইনেও পড়তে পারবেন সংরক্ষিত সংবাদ</p>
        <div className="mt-3 flex gap-2">
          {([
            ["saved", `সংরক্ষিত (${toBn(saved.length)})`],
            ["history", `পড়ার ইতিহাস (${toBn(history.length)})`],
          ] as const).map(([k, label]) => (
            <button
              key={k}
              onClick={() => setTab(k)}
              className={`rounded-full px-3.5 py-1.5 text-[12.5px] font-semibold transition ${
                tab === k ? "bg-white text-brand-700" : "bg-white/15 text-white"
              }`}
            >
              {label}
            </button>
          ))}
        </div>
      </div>

      {list.length > 0 && (
        <div className="flex items-center justify-between border-b border-zinc-200 bg-white px-4 py-2 dark:border-ink-700 dark:bg-ink-800">
          <span className="text-[12px] text-zinc-500 dark:text-zinc-400">
            {toBn(list.length)} টি সংবাদ
          </span>
          <button
            onClick={() => {
              set(tab === "saved" ? "saved" : "history", []);
              toast("তালিকা খালি করা হয়েছে", "🗑️");
            }}
            className="flex items-center gap-1 text-[12px] font-semibold text-brand-600"
          >
            <Icon name="trash" size={13} /> সব মুছুন
          </button>
        </div>
      )}

      <div className="no-scrollbar flex-1 overflow-y-auto pb-6">
        {list.length === 0 ? (
          <EmptyState
            icon={tab === "saved" ? "🔖" : "🕘"}
            title={tab === "saved" ? "কোনো সংবাদ সংরক্ষিত নেই" : "পড়ার ইতিহাস খালি"}
            text={
              tab === "saved"
                ? "যেকোনো সংবাদের বুকমার্ক আইকনে চাপ দিয়ে পরে পড়ার জন্য সংরক্ষণ করুন।"
                : "আপনি যেসব সংবাদ পড়বেন সেগুলো এখানে দেখা যাবে।"
            }
            actionLabel="সংবাদ দেখুন"
            onAction={onGoHome}
          />
        ) : (
          <div className="divide-y divide-zinc-100 bg-white dark:divide-ink-700/60 dark:bg-ink-800/40">
            {list.map((p) => (
              <NewsCard key={p.id} post={p} onOpen={onOpen} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
