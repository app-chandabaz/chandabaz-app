import { useEffect, useRef, useState } from "react";
import type { Post } from "@/lib/api";
import { usePostFeed } from "@/lib/useNews";
import NewsCard from "@/components/NewsCard";
import { Icon } from "@/components/Icons";
import { EmptyState, SkeletonCard } from "@/components/ui";
import { useApp } from "@/lib/store";
import { toBn } from "@/lib/utils";

const SUGGESTED = [
  "চাঁদাবাজি",
  "রাজনীতি",
  "কাতার",
  "প্রবাসী",
  "মধ্যপ্রাচ্য",
  "অর্থনীতি",
  "বাংলাদেশ",
  "ইরান",
];

export default function SearchScreen({
  catMap,
  onBack,
  onOpen,
}: {
  catMap: Map<number, string>;
  onBack: () => void;
  onOpen: (p: Post) => void;
}) {
  const { recentSearches, addSearch, clearSearches } = useApp();
  const [input, setInput] = useState("");
  const [query, setQuery] = useState("");
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const t = setTimeout(() => inputRef.current?.focus(), 250);
    return () => clearTimeout(t);
  }, []);

  /* debounce */
  useEffect(() => {
    const t = setTimeout(() => {
      const term = input.trim();
      setQuery(term);
      if (term.length > 2) addSearch(term);
    }, 500);
    return () => clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [input]);

  const { posts, state, loadMore, loadingMore, hasMore } = usePostFeed(catMap, {
    search: query,
    perPage: 14,
    enabled: query.length > 1,
  });

  const searching = query.length > 1;

  return (
    <div className="animate-screen-in flex h-full flex-col bg-zinc-50 dark:bg-ink-900">
      <div className="flex items-center gap-2 bg-gradient-to-r from-brand-800 to-brand-600 px-3 py-3">
        <button
          onClick={onBack}
          className="grid h-9 w-9 shrink-0 place-items-center rounded-full bg-white/15 text-white"
        >
          <Icon name="back" size={19} />
        </button>
        <div className="flex flex-1 items-center gap-2 rounded-full bg-white px-3.5 py-2 dark:bg-ink-800">
          <Icon name="search" size={17} className="text-zinc-400" />
          <input
            ref={inputRef}
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="chandabazbd.com-এ খুঁজুন..."
            className="w-full bg-transparent text-[13.5px] text-zinc-800 outline-none placeholder:text-zinc-400 dark:text-zinc-100"
          />
          {input && (
            <button onClick={() => setInput("")} className="text-zinc-400">
              <Icon name="close" size={15} />
            </button>
          )}
        </div>
      </div>

      <div
        className="no-scrollbar flex-1 overflow-y-auto pb-6"
        onScroll={(e) => {
          const el = e.currentTarget;
          if (hasMore && !loadingMore && el.scrollTop + el.clientHeight >= el.scrollHeight - 320)
            loadMore();
        }}
      >
        {!searching ? (
          <div className="p-4">
            {recentSearches.length > 0 && (
              <>
                <div className="mb-2 flex items-center justify-between">
                  <h3 className="text-[13.5px] font-bold text-zinc-700 dark:text-zinc-200">
                    সাম্প্রতিক অনুসন্ধান
                  </h3>
                  <button onClick={clearSearches} className="text-[12px] font-semibold text-brand-600">
                    মুছে ফেলুন
                  </button>
                </div>
                <div className="mb-5 flex flex-wrap gap-2">
                  {recentSearches.map((s) => (
                    <button
                      key={s}
                      onClick={() => setInput(s)}
                      className="flex items-center gap-1.5 rounded-full bg-white px-3 py-1.5 text-[12.5px] text-zinc-600 shadow-sm ring-1 ring-zinc-200 dark:bg-ink-800 dark:text-zinc-300 dark:ring-ink-700"
                    >
                      <Icon name="clock" size={12} className="text-zinc-400" />
                      {s}
                    </button>
                  ))}
                </div>
              </>
            )}

            <h3 className="mb-2 flex items-center gap-1.5 text-[13.5px] font-bold text-zinc-700 dark:text-zinc-200">
              <Icon name="fire" size={15} className="text-brand-600" /> জনপ্রিয় বিষয়
            </h3>
            <div className="flex flex-wrap gap-2">
              {SUGGESTED.map((t, i) => (
                <button
                  key={t}
                  onClick={() => setInput(t)}
                  className="rounded-full bg-gradient-to-r from-brand-50 to-brand-100 px-3 py-1.5 text-[12.5px] font-medium text-brand-700 dark:from-ink-800 dark:to-ink-700 dark:text-brand-300"
                >
                  <span className="mr-1 text-[10px] opacity-60">{toBn(i + 1)}</span>
                  {t}
                </button>
              ))}
            </div>

            <p className="mt-8 text-center text-[11.5px] leading-relaxed text-zinc-400">
              🔍 অনুসন্ধান সরাসরি chandabazbd.com সার্ভারে
              <br />
              সম্পাদিত হয়, তাই ফলাফল সবসময় হালনাগাদ।
            </p>
          </div>
        ) : state === "loading" && !posts.length ? (
          <>
            <SkeletonCard />
            <SkeletonCard />
            <SkeletonCard />
          </>
        ) : !posts.length ? (
          <EmptyState
            icon="🔍"
            title="কোনো ফলাফল পাওয়া যায়নি"
            text={`“${query}” সম্পর্কিত কোনো সংবাদ পাওয়া যায়নি। অন্য কীওয়ার্ড দিয়ে চেষ্টা করুন।`}
          />
        ) : (
          <>
            <p className="px-4 py-3 text-[12.5px] text-zinc-500 dark:text-zinc-400">
              <span className="font-bold text-brand-600">{toBn(posts.length)}</span>
              {hasMore ? "+" : ""} টি ফলাফল “{query}” এর জন্য
            </p>
            <div className="divide-y divide-zinc-100 bg-white dark:divide-ink-700/60 dark:bg-ink-800/40">
              {posts.map((p) => (
                <NewsCard key={p.id} post={p} onOpen={onOpen} />
              ))}
            </div>
            {loadingMore && <SkeletonCard />}
          </>
        )}
      </div>
    </div>
  );
}
