import { useCallback, useEffect, useState } from "react";
import { CHANNELS, cachedVideos, fetchAllVideos, type Video } from "@/lib/youtube";
import { Icon } from "@/components/Icons";
import { EmptyState } from "@/components/ui";
import { useApp } from "@/lib/store";
import { toBn, timeAgo } from "@/lib/utils";
import { cn } from "@/utils/cn";

function VideoCard({ v, onPlay }: { v: Video; onPlay: (v: Video) => void }) {
  const [broken, setBroken] = useState(false);
  const color = CHANNELS.find((c) => c.id === v.channelKey)?.color ?? "#475569";
  return (
    <button
      onClick={() => onPlay(v)}
      className="w-full overflow-hidden rounded-2xl bg-white text-left shadow-sm ring-1 ring-zinc-200/70 active:scale-[0.99] dark:bg-ink-800 dark:ring-ink-700"
    >
      <div className="relative aspect-video w-full bg-zinc-800">
        {!broken && (
          <img
            src={v.thumb}
            alt=""
            loading="lazy"
            decoding="async"
            onError={() => setBroken(true)}
            className="h-full w-full object-cover"
          />
        )}
        <div className="absolute inset-0 grid place-items-center bg-black/15">
          <span className="grid h-12 w-12 place-items-center rounded-full bg-black/65 text-white ring-2 ring-white/80">
            <Icon name="play" size={22} filled />
          </span>
        </div>
        <span
          className="absolute left-2.5 top-2.5 rounded-md px-2 py-0.5 text-[10.5px] font-bold text-white"
          style={{ background: color }}
        >
          {v.channelName}
        </span>
      </div>
      <div className="px-3 py-2.5">
        <h3 className="font-serif-bn line-clamp-2 text-[14.5px] font-bold leading-snug text-zinc-900 dark:text-zinc-50">
          {v.title}
        </h3>
        <p className="mt-1 text-[11px] text-zinc-400">{timeAgo(v.minutesAgo)}</p>
      </div>
    </button>
  );
}

export default function VideoScreen({ onPlay }: { onPlay: (v: Video) => void }) {
  const { toast } = useApp();
  const [videos, setVideos] = useState<Video[]>([]);
  const [loading, setLoading] = useState(true);
  const [failed, setFailed] = useState<string[]>([]);
  const [stale, setStale] = useState(false);
  const [filter, setFilter] = useState<string | null>(null);

  const load = useCallback(
    async (notify = false) => {
      setLoading(true);
      let gotFresh = false;
      cachedVideos().then((c) => {
        if (!gotFresh && c.length) setVideos(c);
      });
      const res = await fetchAllVideos((partial) => {
        gotFresh = true;
        if (partial.length) setVideos(partial);
      });
      gotFresh = true;
      if (res.videos.length) setVideos(res.videos);
      setFailed(res.failed);
      setStale(res.usingCache);
      setLoading(false);
      if (notify)
        toast(
          res.videos.length
            ? `${toBn(res.videos.length)} টি ভিডিও আপডেট হয়েছে`
            : "ভিডিও আনা যায়নি, পরে চেষ্টা করুন",
          res.videos.length ? "🎬" : "⚠️"
        );
    },
    [toast]
  );

  useEffect(() => {
    load();
  }, [load]);

  const shown = filter ? videos.filter((v) => v.channelKey === filter) : videos;

  return (
    <div className="flex h-full flex-col bg-zinc-50 dark:bg-ink-900">
      <div className="bg-gradient-to-br from-brand-800 via-ink-800 to-ink-900 px-4 pb-3 pt-4 text-white">
        <div className="flex items-start justify-between">
          <div>
            <h2 className="text-[18px] font-bold">🎬 ভিডিও</h2>
            <p className="text-[11px] text-white/70">
              {toBn(CHANNELS.length)} টি চ্যানেলের সর্বশেষ ভিডিও — অ্যাপের ভেতরেই দেখুন
            </p>
          </div>
          <button
            onClick={() => load(true)}
            className="grid h-9 w-9 place-items-center rounded-full bg-white/15 active:scale-90"
            aria-label="রিফ্রেশ"
          >
            <Icon name="refresh" size={17} className={loading ? "animate-spin" : ""} />
          </button>
        </div>
        <div className="no-scrollbar mt-3 flex gap-2 overflow-x-auto pb-0.5">
          <button
            onClick={() => setFilter(null)}
            className={cn(
              "shrink-0 rounded-full px-3 py-1.5 text-[12px] font-semibold",
              !filter ? "bg-white text-ink-900" : "bg-white/15 text-white"
            )}
          >
            সব ({toBn(videos.length)})
          </button>
          {CHANNELS.map((c) => {
            const n = videos.filter((v) => v.channelKey === c.id).length;
            if (!n) return null;
            return (
              <button
                key={c.id}
                onClick={() => setFilter(filter === c.id ? null : c.id)}
                className={cn(
                  "flex shrink-0 items-center gap-1.5 rounded-full px-3 py-1.5 text-[12px] font-semibold",
                  filter === c.id ? "bg-white text-ink-900" : "bg-white/15 text-white"
                )}
              >
                <span className="h-2 w-2 rounded-full" style={{ background: c.color }} />
                {c.name} ({toBn(n)})
              </button>
            );
          })}
        </div>
      </div>

      <div className="no-scrollbar flex-1 overflow-y-auto pb-6">
        {!loading && (stale || failed.length > 0) && videos.length > 0 && (
          <div className="flex items-center gap-1.5 bg-amber-50 px-4 py-2 text-[11px] text-amber-700 dark:bg-amber-500/10 dark:text-amber-400">
            <Icon name="info" size={12} />
            {stale
              ? "কিছু ভিডিও সংরক্ষিত তালিকা থেকে দেখানো হচ্ছে"
              : `${toBn(failed.length)} টি চ্যানেল এখন পাওয়া যাচ্ছে না`}
          </div>
        )}

        {loading && !videos.length ? (
          <div className="space-y-4 p-4">
            {[0, 1, 2].map((i) => (
              <div
                key={i}
                className="shimmer relative aspect-video w-full overflow-hidden rounded-2xl bg-zinc-200 dark:bg-ink-700"
              />
            ))}
          </div>
        ) : !shown.length ? (
          <EmptyState
            icon="🎬"
            title="ভিডিও আনা যায়নি"
            text="ইন্টারনেট সংযোগ পরীক্ষা করে আবার চেষ্টা করুন।"
            actionLabel="আবার চেষ্টা"
            onAction={() => load(true)}
          />
        ) : (
          <div className="space-y-4 p-4">
            {shown.map((v) => (
              <VideoCard key={v.id} v={v} onPlay={onPlay} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
