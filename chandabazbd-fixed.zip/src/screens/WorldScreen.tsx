import { useCallback, useEffect, useState } from "react";
import type { Post } from "@/lib/api";
import { cachedWorldNews, fetchWorldNews, SOURCES } from "@/lib/world";
import NewsCard from "@/components/NewsCard";
import { EmptyState, SkeletonCard } from "@/components/ui";
import { Icon } from "@/components/Icons";
import { useApp } from "@/lib/store";
import { haptic, toBn } from "@/lib/utils";
import { cn } from "@/utils/cn";

export default function WorldScreen({ onOpen }: { onOpen: (p: Post) => void }) {
  const { worldSources, set, toast } = useApp();
  const [posts, setPosts] = useState<Post[]>(() => cachedWorldNews(worldSources));
  const [loading, setLoading] = useState(true);
  const [failed, setFailed] = useState<string[]>([]);
  const [stale, setStale] = useState(false);
  const [filter, setFilter] = useState<string | null>(null);

  const load = useCallback(
    async (notify = false) => {
      setLoading(true);
      // প্রথমে ক্যাশ দেখাই (তাৎক্ষণিক), তারপর লাইভ আপডেট
      const instant = cachedWorldNews(worldSources);
      if (instant.length) setPosts(instant);

      const { posts: p, failed: f, usingCache } = await fetchWorldNews(worldSources);
      if (p.length) setPosts(p);
      setFailed(f);
      setStale(usingCache);
      setLoading(false);
      if (notify)
        toast(
          p.length
            ? `${toBn(p.length)} টি আন্তর্জাতিক সংবাদ আপডেট হয়েছে`
            : "সংবাদ আনা যায়নি, পরে চেষ্টা করুন",
          p.length ? "🌍" : "⚠️"
        );
    },
    [worldSources, toast]
  );

  useEffect(() => {
    load();
  }, [load]);

  const shown = filter ? posts.filter((p) => p.sourceId === filter) : posts;
  const active = SOURCES.filter((s) => worldSources.includes(s.id));

  const toggleSource = (id: string) => {
    haptic(8);
    const next = worldSources.includes(id)
      ? worldSources.filter((s) => s !== id)
      : [...worldSources, id];
    if (!next.length) {
      toast("অন্তত একটি সোর্স রাখতে হবে", "⚠️");
      return;
    }
    set("worldSources", next);
  };

  return (
    <div className="flex h-full flex-col bg-zinc-50 dark:bg-ink-900">
      <div className="bg-gradient-to-br from-cyan-800 via-ink-800 to-brand-800 px-4 pb-3 pt-4 text-white">
        <div className="flex items-start justify-between">
          <div>
            <h2 className="text-[18px] font-bold">🌍 আন্তর্জাতিক সংবাদ</h2>
            <p className="text-[11px] text-white/70">
              {toBn(active.length)} টি আন্তর্জাতিক সংবাদ সংস্থা থেকে সরাসরি
            </p>
          </div>
          <button
            onClick={() => load(true)}
            className="grid h-9 w-9 place-items-center rounded-full bg-white/15 active:scale-90"
          >
            <Icon name="refresh" size={17} className={loading ? "animate-spin" : ""} />
          </button>
        </div>

        {/* source filter chips */}
        <div className="no-scrollbar mt-3 flex gap-2 overflow-x-auto pb-0.5">
          <button
            onClick={() => setFilter(null)}
            className={cn(
              "shrink-0 rounded-full px-3 py-1.5 text-[12px] font-semibold",
              !filter ? "bg-white text-ink-900" : "bg-white/15 text-white"
            )}
          >
            সব ({toBn(posts.length)})
          </button>
          {active.map((s) => {
            const n = posts.filter((p) => p.sourceId === s.id).length;
            return (
              <button
                key={s.id}
                onClick={() => setFilter(filter === s.id ? null : s.id)}
                className={cn(
                  "flex shrink-0 items-center gap-1.5 rounded-full px-3 py-1.5 text-[12px] font-semibold",
                  filter === s.id ? "bg-white text-ink-900" : "bg-white/15 text-white"
                )}
              >
                <span className="h-2 w-2 rounded-full" style={{ background: s.color }} />
                {s.name} ({toBn(n)})
              </button>
            );
          })}
        </div>
      </div>

      <div className="no-scrollbar flex-1 overflow-y-auto pb-6">
        {!loading && (stale || failed.length > 0) && (
          <div className="flex items-center gap-1.5 bg-amber-50 px-4 py-2 text-[11px] text-amber-700 dark:bg-amber-500/10 dark:text-amber-400">
            <Icon name="info" size={12} />
            {stale
              ? "কিছু সংবাদ সংরক্ষিত কপি থেকে দেখানো হচ্ছে"
              : `${toBn(failed.length)} টি সোর্স এখন পাওয়া যাচ্ছে না`}
          </div>
        )}

        {loading && !posts.length ? (
          <>
            <SkeletonCard />
            <SkeletonCard />
            <SkeletonCard />
            <SkeletonCard />
            <SkeletonCard />
          </>
        ) : !shown.length ? (
          <EmptyState
            icon="🌐"
            title="আন্তর্জাতিক সংবাদ আনা যায়নি"
            text="ইন্টারনেট সংযোগ পরীক্ষা করে আবার চেষ্টা করুন।"
            actionLabel="আবার চেষ্টা"
            onAction={() => load(true)}
          />
        ) : (
          <>
            {shown[0] && (
              <div className="p-4">
                <NewsCard post={shown[0]} onOpen={onOpen} variant="big" />
              </div>
            )}
            <div className="divide-y divide-zinc-100 bg-white dark:divide-ink-700/60 dark:bg-ink-800/40">
              {shown.slice(1).map((p) => (
                <NewsCard key={p.id} post={p} onOpen={onOpen} />
              ))}
            </div>
          </>
        )}

        {/* source manager */}
        <div className="mt-6 px-4">
          <h3 className="mb-2 text-[13px] font-bold text-zinc-700 dark:text-zinc-200">
            সংবাদ সোর্স নির্বাচন করুন
          </h3>
          <div className="overflow-hidden rounded-xl bg-white shadow-sm ring-1 ring-zinc-200 dark:bg-ink-800 dark:ring-ink-700">
            {SOURCES.map((s) => {
              const on = worldSources.includes(s.id);
              return (
                <button
                  key={s.id}
                  onClick={() => toggleSource(s.id)}
                  className="flex w-full items-center gap-3 border-b border-zinc-100 px-3 py-2.5 last:border-0 dark:border-ink-700/60"
                >
                  <span
                    className="grid h-8 w-8 shrink-0 place-items-center rounded-lg text-[11px] font-bold text-white"
                    style={{ background: s.color }}
                  >
                    {s.short}
                  </span>
                  <span className="flex-1 text-left">
                    <span className="block text-[13px] font-semibold text-zinc-800 dark:text-zinc-100">
                      {s.name}
                    </span>
                    <span className="text-[10.5px] text-zinc-400">
                      {s.lang === "bn" ? "বাংলা" : "English"} · RSS
                    </span>
                  </span>
                  <span
                    className={cn(
                      "grid h-5 w-5 place-items-center rounded-md border-2 transition",
                      on
                        ? "border-brand-600 bg-brand-600 text-white"
                        : "border-zinc-300 dark:border-ink-600"
                    )}
                  >
                    {on && <Icon name="check" size={12} />}
                  </span>
                </button>
              );
            })}
          </div>
          <p className="mt-2 text-center text-[10.5px] leading-relaxed text-zinc-400">
            সংবাদগুলো সংশ্লিষ্ট সংস্থার অফিশিয়াল RSS ফিড থেকে সংগৃহীত।
            <br />
            সম্পূর্ণ প্রতিবেদন পড়তে মূল উৎসে যান।
          </p>
        </div>
      </div>
    </div>
  );
}
